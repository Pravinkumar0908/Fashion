<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Online Matka Play Single Patti Play Online Matka Panna</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="cssjs/bt.css">
<link rel="stylesheet" href="cssjs/style.css?v26">
<link rel="stylesheet" href="cssjs/top.css?v46">

<style>
.container-fluid {
	width: 95%;
}
/*header end*/
.gototop:hover {
    color: #fff;
}
.gototop {
  position: fixed;
    right: 20px;
    bottom: 100px;
    background: linear-gradient(0deg,#ff9700 0,#fb4b02 100%);
    padding: 12px;
    border-radius: 80px;
    font-size: 12px;
    box-shadow: 0 0 10px #000;
    color: #fff;
}
.whatapp:hover {
    color: #fff;
} 
.whatapp {
  position: fixed;
    right: 20px;
    bottom: 40px;
    background-color: #00e209;
    padding: 12px;
    border-radius: 80px;
    font-size: 12px;
    box-shadow: 0 0 10px #000;
    color: #fff;
}
/*myform*/
.myform {
    padding-top: 20px;
    margin-top: 40px;
}
.myform h3 {
  font-weight: 700;
  text-align: center;
  color: #fff;
}
.fdklslf {
    background: linear-gradient(64deg,#011557 50%,#051f75 50%);
    box-shadow: 0 0 10px -3px #000;
    margin-top: 30px;
    padding: 16px 20px;
    border-radius: 20px;
    margin-bottom: 40px;
    border-radius: 20px 20px 0 0;
    border: 1px solid #21ebff;
}
.myform h2 {
  background-image: linear-gradient(0deg,#ff9700 0,#fb4b02 100%);
    color: #fff;
    text-shadow: 1px 1px 2px #777;
    border-radius: 20px 0 20px 0;
    padding: 10px 0;
}
.myform h6 {
    font-weight: 600;
    font-size: 22px;
    margin: 20px 0;
}
.form-group label {
    display: inline-block;
    margin-bottom: .5rem;
    background-color: #007bff;
    color: #fff;
    text-align: center;
    width: 100%;
    margin-bottom: 0;
    padding: 10px 0;
}

.numa .row>div {
    margin-bottom: 15px;
}
.numa input {
    border-radius: 0;
}



.shww {
    text-transform: uppercase;
    font-weight: 600;
    text-align: center;
    margin: 20px 0;
    font-size: 32px;
}
.shww .bb {
    color: #007bff;
}

@media only screen and (max-width: 768px) {
/*header*/
.navbar-toggler {
    display: block;
    background-color: white;
}
.djfk button,
.djfk a {
    margin-left: 10px;
}
.dfkjd {
    padding:0 20px;
}
.header {
    padding-top: 120px;
    padding-bottom: 120px;
}
.dfkjd .nav-link {
    padding-left: 10px;
}
/*header*/
.myform {
    margin-top: 0px;
}
} /*media qweuy end*/
@media only screen and (max-width: 500px) {
/*header*/
.djfk {
    display: flex !important;
}
.djfk button,
.djfk a {
    padding: 3px 4px !important;
    font-size: 13px;
}
a.btn.btn-primary.gfdn {
    margin-left: 0;
}
.list-ul {
    width: 100%;
}
/*header*/
.numa .row {
    margin-left: 0;
    margin-right: 0;
}
.numa .row>div {
    padding-left: 5px;
    padding-right: 5px;
}
.numa .row>div:nth-child(1) ,
.numa .row>div:nth-child(7) {
    padding-left: 0px;
}
.numa .row>div:nth-child(6) ,
.numa .row>div:nth-child(12) {
    padding-right: 0px;
}
.footer a {
    font-size: 12px;
}
} /*media qweuy end*/
/*emd -------------*/



input[type="number"] {
    -moz-appearance: textfield;
}

.my-rrow input {
    width: 70%;
}

.row input {
    text-align: center;
    padding-left: 0 !important;
    padding-right: 0 !important;
    height: auto !important;
    border-radius: 0;
}

.my-rrow {
    margin-right: -1px !important;
    margin-left: -1px !important;
}


.my-rrow > div {
    padding-left: 1px !important;
    padding-right: 1px !important;
}

.my-sk {
display: -webkit-flex;
display: -moz-flex;
display: -ms-flex;
display: -o-flex;
display: flex;
}
.my-sk input {
	height: auto;
}


</style>
</head>
<body>

<div id="#top"></div>
<div class="hea" style="height: 100px;"></div>
<div class="top-div fixed-top">
   

<nav class="navbar navbar-light bg-light d-flex jcc dsnfds"><a class="navbar-brand " href="index.php">
<img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
    border-radius: 9px;"></a>
<div class="d-flex djfk">
<a href="login.php" class="btn btn-warning">LOGIN</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span></button></div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
<li class="nav-item"><a class="nav-link" href="single.php">SINGLE</a></li>
<li class="nav-item"><a class="nav-link" href="jodi.php">JODI</a></li>
<li class="nav-item"><a class="nav-link" href="single-patti.php">SINGLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="double-patti.php">DOUBLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="half-sangam.php">HALF SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="full-sangam.php">FULL SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="star-line.php">STARLINE</a></li>
<li class="nav-item"><a class="nav-link" href="howtoplay.php">HOW TO PLAY</a></li>
<li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
<li class="nav-item"><a class="nav-link" href="register.php">REGISTER</a></li>
 </ul></div></nav>
   </div>


<div class="myform">
	<div class="container-fluid fdklslf">
	    		<h2 class="text-center">SINGLE PATTI (10 KA 14400)</h2>
		<span id="lotterytimeerror" style="color:red;"></span>
		<h6>Select Your Game</h6>
		<form class="row" action="" method="POST" onsubmit="return confirm('Are You Sure ?\nOnce you Proceed You Cannot Revert.');"> 
		
		


<div class="form-group col-md-6 col-12">
			    
			    
			  <label for="market">SELECT YOUR MARKET</label>
			  <select class="form-control" id="market" name="market" onchange="get_dates(this.value)" required>
			      <option value=""> Select Market </option>
			  			   
			                                   
                                                                
                                                                    <option value="RAJDHANI_DAY_CLOSE">RAJDHANI DAY CLOSE (05:10 PM)</option>
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                    <option value="SUPREME_DAY_CLOSE">SUPREME DAY CLOSE (04:35 PM)</option>
                                                                                        
                                                                    <option value="KALYAN__OPEN" >KALYAN  OPEN (04:30 PM)</option>
                                                                
                                                                    <option value="KALYAN__CLOSE">KALYAN  CLOSE (06:30 PM)</option>
                                                                                        
                                                                    <option value="SRIDEVI_NIGHT__OPEN" >SRIDEVI NIGHT  OPEN (07:15 PM)</option>
                                                                
                                                                    <option value="SRIDEVI_NIGHT__CLOSE">SRIDEVI NIGHT  CLOSE (08:15 PM)</option>
                                                                                        
                                                                    <option value="SUPREME_NIGHT__OPEN" >SUPREME NIGHT  OPEN (08:35 PM)</option>
                                                                
                                                                    <option value="SUPREME_NIGHT__CLOSE">SUPREME NIGHT  CLOSE (10:35 PM)</option>
                                                                                        
                                                                    <option value="MILAN_NIGHT__OPEN" >MILAN NIGHT  OPEN (08:50 PM)</option>
                                                                
                                                                    <option value="MILAN_NIGHT__CLOSE">MILAN NIGHT  CLOSE (10:50 PM)</option>
                                                                                        
                                                                    <option value="RAJDHANI_NIGHT__OPEN" >RAJDHANI NIGHT  OPEN (09:10 PM)</option>
                                                                
                                                                    <option value="RAJDHANI_NIGHT__CLOSE">RAJDHANI NIGHT  CLOSE (11:10 PM)</option>
                                                                                        
                                                                    <option value="KALYAN_NIGHT__OPEN" >KALYAN NIGHT  OPEN (09:11 PM)</option>
                                                                
                                                                    <option value="KALYAN_NIGHT__CLOSE">KALYAN NIGHT  CLOSE (11:25 PM)</option>
                                                                                        
                                                                    <option value="MAIN_RATAN_OPEN" >MAIN RATAN OPEN (09:25 PM)</option>
                                                                
                                                                                        
                                                                    <option value="MAIN_BAZAR__OPEN" >MAIN BAZAR  OPEN (11:53 PM)</option>
                                                                
                                                                    <option value="MAIN_BAZAR__CLOSE">MAIN BAZAR  CLOSE (11:59 PM)</option>
                                                                                      
                                
				 			  </select>
			</div>
			
			
			<div class="form-group col-md-6 col-12">
		    <label for="date">SELECT DATE</label>
		    <select class="form-control" id="date" name="date" required>
			   <option value="26/10/2023">26/10/2023</option>
		    </select>
		  </div>

			<div class="form-group col-12 numa">
				<label class="text-center numb">1</label>
				<div class="row my-rrow label-sm-text">
				                				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>128</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_128">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>137</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_137">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>146</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_146">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>236</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_236">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>245</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_245">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>290</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_290">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>380</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_380">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>470</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_470">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>489</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_489">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>560</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_560">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>579</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_579">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>678</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_678">
    					</div>
    									</div>
			</div>
			<!-- 02 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">2</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>129</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_129">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>138</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_138">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>147</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_147">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>156</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_156">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>237</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_237">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>246</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_246">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>345</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_345">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>390</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_390">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>480</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_480">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>570</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_570">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>589</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_589">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>679</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_679">
    					</div>
    									</div>
			</div>
			<!-- 03 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">3</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>120</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_120">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>139</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_139">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>148</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_148">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>157</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_157">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>238</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_238">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>247</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_247">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>256</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_256">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>346</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_346">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>490</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_490">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>580</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_580">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>670</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_670">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>689</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_689">
    					</div>
    									</div>
			</div>
			<!-- 04 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">4</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>130</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_130">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>149</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_149">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>158</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_158">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>167</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_167">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>239</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_239">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>248</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_248">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>257</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_257">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>347</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_347">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>356</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_356">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>590</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_590">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>680</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_680">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>789</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_789">
    					</div>
    									</div>
			</div>
			<!-- 05 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">5</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>140</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_140">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>159</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_159">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>168</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_168">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>230</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_230">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>249</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_249">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>258</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_258">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>267</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_267">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>348</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_348">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>357</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_357">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>456</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_456">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>690</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_690">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>780</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_780">
    					</div>
    									</div>
			</div>
			<!-- 06 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">6</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>123</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_123">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>150</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_150">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>169</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_169">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>178</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_178">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>240</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_240">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>259</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_259">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>268</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_268">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>349</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_349">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>358</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_358">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>367</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_367">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>457</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_457">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>790</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_790">
    					</div>
    									</div>
			</div>
			<!-- 07 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">7</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>124</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_124">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>160</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_160">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>179</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_179">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>250</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_250">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>269</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_269">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>278</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_278">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>340</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_340">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>359</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_359">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>368</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_368">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>458</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_458">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>467</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_467">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>890</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_890">
    					</div>
    									</div>
			</div>
			<!-- 08 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">8</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>125</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_125">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>134</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_134">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>170</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_170">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>189</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_189">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>260</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_260">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>279</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_279">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>350</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_350">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>369</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_369">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>378</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_378">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>459</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_459">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>468</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_468">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>567</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_567">
    					</div>
    									</div>
			</div>
			<!-- 09 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">9</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>126</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_126">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>135</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_135">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>180</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_180">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>234</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_234">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>270</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_270">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>289</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_289">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>360</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_360">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>379</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_379">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>450</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_450">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>469</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_469">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>478</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_478">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>568</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_568">
    					</div>
    									</div>
			</div>
			<!-- 0 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">0</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>127</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_127">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>136</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_136">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>145</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_145">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>190</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_190">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>235</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_235">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>280</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_280">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>370</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_370">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>389</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_389">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>460</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_460">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>479</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_479">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>569</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_569">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>578</label>
    						<input type="number" class="form-control nnnd" min="10" name="single_patti_578">
    					</div>
    									</div>
			</div>
		  <div class="form-group col-12">
		  	<h5 class="shww">
		  		<span class="aa">Total Point :</span>
		  		<span class="bb">00</span>
		  		<input type="hidden" name="total_point" id="total_point" value="">
		  	</h5>
		  </div>
		  <div class="form-group col-12 justify-content-center d-flex">
		      									You Need to Login First.
						 					  </div>
		</form>
	</div>



<h3>DOWNLOAD THE GAME APP</h3> 
	<h3>AND START EARNING</h3>
	<div class="text-center mt-2 mb-2">
	    
	    <a href="https://matka.games/apk/online_matka_play.apk" class="btn btn-success" style="font-size: 25px;text-transform: uppercase;    background-image: linear-gradient(45deg, #E91E63, #F44336);    border-color: #fff;   border-radius: 10px;"> 
						<i class="fas fa-download"></i>
						<span>&nbsp;</span>
						<span>Download APP</span>
					</a>
	</div>

<div class="my-btn">
<a href="#top" class="gototop"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;"> </a>
<a href="https://api.whatsapp.com/send?phone=919339447115&amp;text=I%20have%20Some%20query%20Regarding%20onlinematkaplay.net" class="whatapp"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;"></a>





<!--<div class="down-div"> 
<a href="https://matka.games/apk/online_matka_play.apk" class="download-app"> 
<span>
<i class="fas fa-download"></i>&nbsp;&nbsp;Download Android App
</span>
</a>
</div>-->


</div>



<script> 
if ('serviceWorker' in navigator) {
    console.log("Will the service worker register?");
    navigator.serviceWorker.register('service-worker.js')
        .then(function(reg) {
            console.log("Yes, it did.");
        }).catch(function(err) {
            console.log("No it didn't. This happened:", err)
        });
}
 
</script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="cssjs/p.js"></script>
<script src="cssjs/bt.js"></script>
<script src="cssjs/app.js"></script>
<script type="text/javascript">
function get_dates(market_id){var date=document.getElementById('date').value; if(market_id=="" || market_id==null){document.getElementById('lotterytimeerror').innerHTML="Please select market!!";return}$.ajax({url: 'getdatebylotteryId.php?market_id=' + market_id +'&date=' + date,success: function(response){var splited=response.split("|");var flag=splited[0];var dates=splited[1];if(flag !=1){document.getElementById('lotterytimeerror').innerHTML="Today lottery play time is closed , you can play another day lottery."; alert('Today lottery play time is closed , you can play another day lottery');document.getElementById('date').innerHTML=dates}else{document.getElementById('lotterytimeerror').innerHTML=""; document.getElementById('date').innerHTML=dates}}})}
</script>

<script>
$('li').click(function() {
    $(this).toggleClass("selected");
}); 
$('li').click(function(e){ //on add input button click
	// e.preventDefault();
	// if(x < max_fields){ //max input box allowed
		// x++; //text box increment
		$('.input-fields').append(`
			<div class="dynamic-input col-md-2 col-3">
				<label>num</label>
				<input type="number" name="number[]"/>
				<a class="delete">x</a>
			</div>
		`); //add input box
	
});



$('.myform').on('input', '.nnnd', function(event) {
  var total = 0;
  $('.nnnd').each(function() {
    total += parseInt(this.value, 10) || 0;
  });
  $('.bb').html(total);
  document.getElementById("total_point").value = total;
})


$('.nnnd').bind('copy paste cut',function(e) {
  e.preventDefault();
});
</script>
</body>
</html>