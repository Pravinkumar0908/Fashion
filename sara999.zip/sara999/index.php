
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sara999 |Online Matka Play|Play Full Rate Trusted Best Satta App</title>
    <meta name="Description" content=".">
    <meta name="keywords" content=""/>
    <meta name="keywords" content=""/>

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="cssjs/home.css?v1">

</head>
<body>
    <div id="#top"></div>
    <div class="hea" style="height: 53px;"></div>
    <div class="top-div fixed-top">

        <nav class="navbar navbar-light bg-light d-flex jcc dsnfds">
            <a class="navbar-brand " href="index.php">
                <img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
                    border-radius: 9px;">
            </a>
            <div class="d-flex djfk">
                <a href="login.php" class="btn btn-warning">LOGIN</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
        <nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="single.php">SINGLE</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="jodi.php">JODI</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="single-patti.php">SINGLE PATTI</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="double-patti.php">DOUBLE PATTI</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="half-sangam.php">HALF SANGAM</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="full-sangam.php">FULL SANGAM</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="star-line.php">STARLINE</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="howtoplay.php">HOW TO PLAY</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">LOGIN</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">REGISTER</a>
                    </li>
                </ul>
            </div>
        </nav>

    </div>
    <div class="htbox" style="background: linear-gradient(#d7ae0a,rgba(0, 0, 0, 0.35)100%),url(banner.jpg);background-repeat: no-repeat;background-size: cover;overflow: hidden;position: relative;padding-top: 100px;text-align: center;z-index: 1;background-position: bottom;">
        <p class="mb-0">
        <p>
            <strong>Welcome to Sara999 play website&nbsp;</strong>
        </p>

        <div class="container-fluid fdskfn">
            <h1 style="color:white;">
                Online Matka Play
                <br>
                Matka Online Game App
            </h1>
            <p class="mb-0">India's #1 Trusted Satta Matka Playing Site</p>
            <p>play official Matka Head Office Website</p>
            <a href="tel:9339447115" class="btn btn-primary dfnkskfn">+91-9339447115</a>

            <a href="apk/online_matka_play.html" class="btn btn-primary dfnkskfn">
                <span>
                    <img src=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAAHYAAAB2AH6XKZyAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAACl9JREFUeJzVm3twVdUVh7+174OYhICSMBBtccSQIOhgxUp9gqgDdhhtdSi0Fem0StWO1vqgwljjWPtQ+xCniAQt1ZFaIlVRQmIHDRYBsaXaFiZQlLeAoDwCArn3nNU/8rrn3HPuPefeG2zXzJ19svfae6/f2mutvdc+J0IPU+9XtNo2XAjUiFCtUGVsShTKRClD+UzgCMoRge0oGwQ2AGsPFLGaq+V4T8onBR9xocaLixgvcD3C5UBl12SaUmrH5KllR3tK3VFRVgINEViwd6LsLrS4BVNAnwYdnEhyhwiTgXLHJOGBO/u0lxbK68CcfZN4FenqlRflrYDSxTpMhRnAN4CIY/DCAPfq+y+Bn+35DwupFTsf+XNXQJOWlBznfoS7gKhjUD/AnaULZAjg7jHWqnLrninyTq4wclJA8WK9RoQngYGOwU4ccLdr/C6uTN/yHTkWFks4Bbyp0ZJWfopwb2rfHgXuxefNv94IE7dNlXVhIAVWQGmDVmCxWGFUV+eQQvcE8NQ6A622zaQdN0lDUFyBFFC0RAdFbJqA6nyELiTwLgWk11kC07beJE8XRAF9GnRw0mI5cOoJB57BrbKMoSr8YOvNMjsvBZQ2aIVarBBlyP8J8NQxFLhx8y3yXE4KqFiopUd78VdgRFihP2fgqXxtKOM+uE3e9MNp/BqOxZktMEI6JhIFsVOeM9WF5e+pMWziorxQ/YRW+uH0tIDei/W72MwLu1oZV9I1Rv+4ckuNRdzAUy0Rdh4R/y0zpBxuPqMs3zCAsUwUK6sC+i7SQXaEdSglPQG8k++lsQkuKG8/xW46JFz+WhwtMPBUPoF7Wu6Qx9x401zANjwudjv4bCaG7d+WqS4KnN+v+wh/ZplS0Uu7BS6M+XfL2S7rg0Mf00EZFVD2ol4tyjU97bMGMC7bi0kKX4GAu37FCI9mVIARHgwyOF4ThBQwjfJQqK+FprddP/QR/ZKnAk5+SceLMjIw8DxXy00FBe4vm0SU6d4WkGR6KOB5rpavBRQCeCbZ4PoRj2iVQwF9XtDBolwaGkgeQqdZQM/4vVeb0SRTHAqICTeIImlm2hPA/RRA7uOGjUnADdSq6XYB5ZuBgOfh924T94wB+QAPJ9ugEXG+AmBOXqhfFKUqEPAcrMDPtz0VkA/wkLIZiysBTNTiilDaz9FM3XW+CjhB+YOxGQMQFeXStGOk0hMXFd190vE7V9dnzlyySD9+YNToWi2KijKsi7GngWdSgMtlegp4Sv4Sb7Woioqd22VHJuBlcTiaAMvy6euRhKe6hht4xEBxDA4fzx94qrxGqIlK+/u5nIGnChsVmDUmwbjTbT46IkxvjrJ6l/E1bQd5uCHAyIE2P7sqSWWZsmyT4e4lMew8gXc+G2WICRQ4AkbkSwbajDu9fRkrS5T54xNMPcvyDFRpFpBqBR08k4ZbzPt6gsqy9g5jz7S5eJAdWDbHfN51/aJuswtqYl51Sdd1Q8TAzAuTDCtXHlgepc2ia6tNU0AK8FgEZl6W5LrhafcXJJNOJeYTkwz0Ntk0l2nF3fyrdxpe3OB4PQjAtUMsnr+mjYHF6m8BHfUVJylPfy3hCf619RHWbDE5r7jHSbdDAQU69aEwsznKT96KknSt8vD+yqKJCUadavsqYGi58vykBOdWOjsr8NTKCA80RJ2HtQLkD1G/AOUuwwSa+nURdhwUfn1Vkr69utGeXKTMnZDgVysc71IBmFBjM+2CJL1cTa3HYGZDjLc/MDm7pp+8KK0yqE61UMDdfANLlFnjEwzr77HkAWjbfuFHL8XYvE8KCjyF7zfGz+9D5QU+dXtahSmL4rzqERey0dsfGqY8F2fLPsk5JmWrMzb7oqIcov17HfdJKU2DxTGYMSrJ8HKbxs0R6v4eyarptgTMbIqyfrdwz6XJtLtANynwh3cizH4rim0Hc82pF1mMqbFo2WV4vCnK8TbfFXeOARujomxEGRnkrc73zrGYOLQ9Op9VkWT9HmHldo+DjqtEYcE/Imz5RPjl1QnKirzBH01AbUOMZS3GcT/gB1wULhhs8/0xSQCqB1rsPSTMb44Ei2tCixH4d5op+ZhOVV9ndB5yimY+JLnaVm0xfPv5OJv2pZvBnlbh5gVx3mgx/qbr4ZqDy53xZXCFHcj8sWmjlE1GlbcczJn8yCW0wWfwDD67Y78wdUGcNzZ2JwRrthq+9UyMll2ScYv1anOnFYZgscAoq5pr5ViUBMvEkFMW52em2czv6DG49+UYwwfYxCPw3vbuLc7P/dxjdLV5UKaY1FXavAlgPrxDtomyMUjk9JrI1zwDrMK6jwzvbTMZ3S+Ia3rKlcU1gb9AhwUZ5Y9BhFbXZF0rlsFngyojF+Bip79hyuR+KW1b35jFqi4FYDNfFM024YHPnLMNKPUJgoUAHtCSBvRxrsqBw5LG51aKUZ7ttB0D0HKnbBFlebYJP/zUqYDxNTblJ2lokKHrfNr6lSiXn+30za17fAJp9xiWsXm2k78riBqbX2SbsHmTwU5ReN8i5ZEJSfp3Znl5gAz0ViflV1Gi1E5OUlbcLZBtw8p13dmiZ0yyqW+aLZtS3biLhj+qa1DOl44xHWXH80Pjkkw4y5mqth6DZRsj7Dwg7XEiRUmS8pwWuTvHT3lO5XH07fhbBCpPUS4bZlF6krO98d0Ij9VHMx1+1CgjGp+Uf3b2ceReEYv7baHRC3hn3ePNEUaeZjOwrFu63kVw7Tnp+fuJpN37hbolkbR7xdRSlT81zukGD65zxPs/liZR/pzJdPcfEW5/McZHB7Mc6k8g7f5UmDkvxqHD4u067WVrHO52903/QiTJD0U57BmRO36b9wo3zo/x8vsRLI/zwYkiy4YlqyPc9tsY23enR39HjIEHXpsjO91jeC7jiId1qii/D3I6rChRLq6yGVyunFKsnvty2mRu3/ao86tXhf2twtbdwqp1hv2HpFseL3kBbJpLD3BFfX2Aj6Q66dyHdL4oNxbiujz0RUUW/pBjfGwJI5rmyi4vnL7fCVpF3CbK2kLdF+az3+dU114eV5joBx4yWADAebVabmAFSnXY1SrkiqclREHmB1uESUvmSn0mjFlD+fm1eoZYLBc4reDAA7pVSOCdvW5tqJM52fAF2ssuqtVKK0kjytn/48ABkgrTltbJM0GwBd7Mv3yf9osIr4hykZfQmYDkGkhDAgc4qMLEpXPl9aC4fIOgm9b8XD7pFWe0UR4Uxe4MNEHT1jCBNNBbHRcprLVsRoYBDyEsIJUuma5fVXhKbE6FkCueIQjmsOIASWCWFjFj6RPh/8s05/PsebVaXHKYe1HuE4h/DsBB+Zst3NpYJ+/miiPvA/3ou7RGbGYoTBZtT67CbnuhgcN7qjy8dB6LsnJmoYJlNFfcqWfYyu0ok0XpH3jL9GtLpyTQBMxpqGNJvsA7qeAp3ehajUb2Mg64zghjUb6QB/DPgBUIS5KGF16fIx8XWt4ez2mvnKZVYrjQCDW2TbWBM1F6i9KH9ldyRxQOCxwGdoiyQYUNoqwtPsg79fXS1pPy/RdqfGoctLzh5gAAAABJRU5ErkJggg==" style="max-height: 30px;">

                        &nbsp;&nbsp;Download Android App
                </span>
            </a>

        </div>
    </div>
    <div class="my-width">

        <div class="result" style="margin-top: 10px;">
            <div class="container-fluid">
                <h2 class="my-bdr">Satta Matka Game Results</h2>
                <div class="row my-bdr" style="margin: 10px 0 40px;">

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>RAJDHANI DAY</h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 03:10 AM </span>
                                <span> 05:10 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=RAJDHANI DAY"> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>SRIDEVI </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 11:40 AM </span>
                                <span> 12:40 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=SRIDEVI "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>TIME BAZAR </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 01:00 PM </span>
                                <span> 03:10 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=TIME BAZAR "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>MADHUR DAY</h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 01:40 PM </span>
                                <span> 02:40 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=MADHUR DAY"> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>MILAN DAY</h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 02:05 PM </span>
                                <span> 04:05 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=MILAN DAY"> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>SUPREME DAY</h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 03:35 PM </span>
                                <span> 04:35 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=SUPREME DAY"> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>KALYAN </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 04:30 PM </span>
                                <span> 06:30 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=KALYAN "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>SRIDEVI NIGHT </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 07:15 PM </span>
                                <span> 08:15 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=SRIDEVI NIGHT "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>SUPREME NIGHT </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 08:35 PM </span>
                                <span> 10:35 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=SUPREME NIGHT "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>MILAN NIGHT </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 08:50 PM </span>
                                <span> 10:50 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=MILAN NIGHT "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>RAJDHANI NIGHT </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 09:10 PM </span>
                                <span> 11:10 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=RAJDHANI NIGHT "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>KALYAN NIGHT </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 09:11 PM </span>
                                <span> 11:25 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=KALYAN NIGHT "> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>MAIN RATAN</h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 09:25 PM </span>
                                <span> 12:55 AM </span>
                            </h4>

                            <a href="play-option-main.php?market=MAIN RATAN"> Play Now</a>
                        </div>
                    </div>

                    <div class="col-12 na8">
                        <div class="rsltdiv">
                            <h6>MAIN BAZAR </h6>
                            <h5>***-**-***</h5>
                            <h4>
                                <span> 11:53 PM </span>
                                <span> 11:59 PM </span>
                            </h4>

                            <a href="play-option-main.php?market=MAIN BAZAR "> Play Now</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="notice text-center">

            <div class="container-fluid">

                <div class="row" style="margin-top: 10px;">
                    <div class="col-12 satta-div my-bdr" style="margin-bottom: 0px;">

                        <div class="jcc jd45" style="line-height: 31px;">

                            <p>
                                MINIMUM DEPOSIT :- 500 
                                <br>

                                MINIMUM WITHDRAWAL :- 500 
                                <br>

                                MAXIMUM WITHDRAWAL :- NO LIMITS 
                            </p>

                        </div>

                    </div>
                </div>

            </div>
        </div>

        <div class="notice text-center">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 satta-div my-bdr">
                        <h3>Online Matka Game Play Rates</h3>
                        <div class="d-flex jcc jd45">
                            <p>SINGLE</p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">97</span>
                            </div>
                        </div>
                        <div class="d-flex jcc jd45">
                            <p>JODI </p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">1000</span>
                            </div>
                        </div>
                        <div class="d-flex jcc jd45">
                            <p>SINGLE PATTI</p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">1600</span>
                            </div>
                        </div>
                        <div class="d-flex jcc jd45">
                            <p>DOUBLE PATTI</p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">3500</span>
                            </div>
                        </div>

                        <div class="d-flex jcc jd45">
                            <p>TRIPLE PATTI</p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">10000</span>
                            </div>
                        </div>

                        <div class="d-flex jcc jd45">
                            <p>HALF SANGAM</p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">12000</span>
                            </div>
                        </div>

                        <div class="d-flex jcc jd45">
                            <p>FULL SANGAM</p>
                            <div style="line-height: 37px;">
                                <span class="lup">10</span>
                                <span class="fot">ka</span>
                                <span class="lup">170000000</span>
                            </div>
                        </div>

                    </div>
                </div>
                <hr class="my-hr hr-1">
            </div>

        </div>

        <hr>
        <div class="starl text-center">
            <div class="container-fluid">
                <h2>MAIN STARLINE</h2>
                <table>
                    <thead>
                        <tr>
                            <th>TIME</th>
                            <th>RESULT</th>
                            <th>TIME</th>
                            <th>RESULT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>10:00 am</td>
                            <td>***-*</td>
                            <td>11:00 am</td>
                            <td>***-*</td>
                        </tr>

                        <tr>
                            <td>12:00 pm</td>
                            <td>***-*</td>
                            <td>1:00 pm</td>
                            <td>***-*</td>
                        </tr>

                        <tr>
                            <td>2:00 pm</td>
                            <td>***-*</td>
                            <td>3:00 pm</td>
                            <td>***-*</td>
                        </tr>

                        <tr>
                            <td>4:00 pm</td>
                            <td>***-*</td>
                            <td>5:00 pm</td>
                            <td>***-*</td>
                        </tr>

                        <tr>
                            <td>6:00 pm</td>
                            <td>***-*</td>
                            <td>7:00 pm</td>
                            <td>***-*</td>
                        </tr>

                        <tr>
                            <td>8:00 pm</td>
                            <td>***-*</td>
                            <td>9:00 pm</td>
                            <td>***-*</td>
                        </tr>

                        <tr>
                            <td>10:00 pm</td>
                            <td>***-*</td>
                            <td></td>
                            <td></td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <hr>
        <div class="gtable">
            <div class="container-fluid">
                <h2>Satta Matka Result Time</h2>
                <table>
                    <thead>
                        <tr>
                            <th>MARKET</th>
                            <th>OPEN</th>
                            <th>CLOSE</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td>RAJDHANI DAY</td>
                            <td>03:10 AM</td>
                            <td>05:10 PM</td>
                        </tr>

                        <tr>
                            <td>SRIDEVI </td>
                            <td>11:40 AM</td>
                            <td>12:40 PM</td>
                        </tr>

                        <tr>
                            <td>TIME BAZAR </td>
                            <td>01:00 PM</td>
                            <td>03:10 PM</td>
                        </tr>

                        <tr>
                            <td>MADHUR DAY</td>
                            <td>01:40 PM</td>
                            <td>02:40 PM</td>
                        </tr>

                        <tr>
                            <td>MILAN DAY</td>
                            <td>02:05 PM</td>
                            <td>04:05 PM</td>
                        </tr>

                        <tr>
                            <td>SUPREME DAY</td>
                            <td>03:35 PM</td>
                            <td>04:35 PM</td>
                        </tr>

                        <tr>
                            <td>KALYAN </td>
                            <td>04:30 PM</td>
                            <td>06:30 PM</td>
                        </tr>

                        <tr>
                            <td>SRIDEVI NIGHT </td>
                            <td>07:15 PM</td>
                            <td>08:15 PM</td>
                        </tr>

                        <tr>
                            <td>SUPREME NIGHT </td>
                            <td>08:35 PM</td>
                            <td>10:35 PM</td>
                        </tr>

                        <tr>
                            <td>MILAN NIGHT </td>
                            <td>08:50 PM</td>
                            <td>10:50 PM</td>
                        </tr>

                        <tr>
                            <td>RAJDHANI NIGHT </td>
                            <td>09:10 PM</td>
                            <td>11:10 PM</td>
                        </tr>

                        <tr>
                            <td>KALYAN NIGHT </td>
                            <td>09:11 PM</td>
                            <td>11:25 PM</td>
                        </tr>

                        <tr>
                            <td>MAIN RATAN</td>
                            <td>09:25 PM</td>
                            <td>12:55 AM</td>
                        </tr>

                        <tr>
                            <td>MAIN BAZAR </td>
                            <td>11:53 PM</td>
                            <td>11:59 PM</td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <hr class="myhr4">
        <div class="chart-list text-center">
            <div class="container-fluid">
                <div class="chart-card">
                    <h3>All Matka Jodi Chart Records</h3>
                    <div>
                        <a href="chart/getChart_jodi.php?market=RAJDHANI DAY">RAJDHANI DAY</a>

                        <a href="chart/getChart_jodi.php?market=SRIDEVI ">SRIDEVI </a>

                        <a href="chart/getChart_jodi.php?market=TIME BAZAR ">TIME BAZAR </a>

                        <a href="chart/getChart_jodi.php?market=MADHUR DAY">MADHUR DAY</a>

                        <a href="chart/getChart_jodi.php?market=MILAN DAY">MILAN DAY</a>

                        <a href="chart/getChart_jodi.php?market=SUPREME DAY">SUPREME DAY</a>

                        <a href="chart/getChart_jodi.php?market=KALYAN ">KALYAN </a>

                        <a href="chart/getChart_jodi.php?market=SRIDEVI NIGHT ">SRIDEVI NIGHT </a>

                        <a href="chart/getChart_jodi.php?market=SUPREME NIGHT ">SUPREME NIGHT </a>

                        <a href="chart/getChart_jodi.php?market=MILAN NIGHT ">MILAN NIGHT </a>

                        <a href="chart/getChart_jodi.php?market=RAJDHANI NIGHT ">RAJDHANI NIGHT </a>

                        <a href="chart/getChart_jodi.php?market=KALYAN NIGHT ">KALYAN NIGHT </a>

                        <a href="chart/getChart_jodi.php?market=MAIN RATAN">MAIN RATAN</a>

                        <a href="chart/getChart_jodi.php?market=MAIN BAZAR ">MAIN BAZAR </a>

                    </div>
                </div>
                <div class="chart-card">
                    <h3>All Matka Panel Chart Records</h3>
                    <div>
                        <a href="chart/getChart.php?market=RAJDHANI DAY">RAJDHANI DAY</a>

                        <a href="chart/getChart.php?market=SRIDEVI ">SRIDEVI </a>

                        <a href="chart/getChart.php?market=TIME BAZAR ">TIME BAZAR </a>

                        <a href="chart/getChart.php?market=MADHUR DAY">MADHUR DAY</a>

                        <a href="chart/getChart.php?market=MILAN DAY">MILAN DAY</a>

                        <a href="chart/getChart.php?market=SUPREME DAY">SUPREME DAY</a>

                        <a href="chart/getChart.php?market=KALYAN ">KALYAN </a>

                        <a href="chart/getChart.php?market=SRIDEVI NIGHT ">SRIDEVI NIGHT </a>

                        <a href="chart/getChart.php?market=SUPREME NIGHT ">SUPREME NIGHT </a>

                        <a href="chart/getChart.php?market=MILAN NIGHT ">MILAN NIGHT </a>

                        <a href="chart/getChart.php?market=RAJDHANI NIGHT ">RAJDHANI NIGHT </a>

                        <a href="chart/getChart.php?market=KALYAN NIGHT ">KALYAN NIGHT </a>

                        <a href="chart/getChart.php?market=MAIN RATAN">MAIN RATAN</a>

                        <a href="chart/getChart.php?market=MAIN BAZAR ">MAIN BAZAR </a>

                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="about-us">
                <h4>ABOUT US</h4>
                <p>We Welcome You To World's Most Popular Matka Online Play Website Sara999 Here You Can Play All Games Like Kalyan, Kalyan Night, Milan Day & Night, Rajdhani Day & Night, Starline.</p>
                <p>We are giving you full rate of all rate no one in matka industry give full rate rather then this website</p>
                <p>Download Our Official App For best Online Matka Play Expierience. Just Rejister An Id Then Add Funds To Your Wallet.You Can Play Now its simple.</p>
                <p>Full Sangam Matka Online Play, Matka Online Open, Rs Games, Matka Rates, Online Matka Play Websites, Online Matka Play Websites, Online Satta Games, Online Matka rejistration.</p>
                <h4>
                    <a href="#" title="Online Matka Play">Online Matka Play</a>
                </h4>
                <p>
                    Online Matka Play is the highest-rated platform for playing online Matka. Our web application interface is the best of the online Matka websites. This will help you guess accurately and earn massive points to play online Matka. We strive to follow the most acceptable practices to make Matka play more fun. Have the best experience on the Online Matka, play with your skills and earn big rewards. For more information, please contact us right now.
                    <br>
                    <br>
                    We at online Matka play strive to provide you the best advice and tips, which only not gives you the best site to play this fantastic online Matka play but confidence also. We are committed to providing you the utmost ease, and for best results, feel free to call us to play an online Matka game. You can find all the updated live results from our one-stop site. Download our free download app to play this incredible game.
                </p>
                <h4>
                    <a href="#" title="Online Matka">Online Matka</a>
                    play the best gambling game.
                </h4>
                <p>
                    Satta Matka online play is our online gambling game. Also known as Satta Matka play, it is the world of Experts Guessing Forum and one of the most visited Satta Play sites among people working in Satta Matka. Our site has established itself as an undisputed leader in this area since it began its activities a few years ago. And we believe this success is the result of our constant efforts to publish the results of all online Matka play faster and exceptionally than all other sites present on the internet. 
                    <br>
                    <br>
                    Download the fascinating Satta online app, play your own Matka game and win from the comfort of your home! Download it on Google Now. The bonus is even more fulfilling as we always feel motivated and appreciated when we find prizes! This is happening in this game. As we will not only spend a pleasurable time but also get the handsome amount with minimum investment. 
                    <br>
                    <br>
                    Everyone from us is curious about how lucky is he or she! Well, we have the best option for you, which is fun also; let's try the Matka trick of luck and play online Matka. You need to invest the least amount of money. Follow our tips because we care for you the most. Join us today.
                </p>
                <h4>Online Play Matka with us</h4>
                <p>
                    The online Matka play app is incredibly simple and easy to use. Every bazaar has Satta Matka Jodi and a graphic designer because people choose to play Matka online and have a deep belief in fortune-telling and the fate of the stars. We also tend to use Jodi charts and game panel charts in all games. Provides the fastest score for the selected game. This online Matka game helps you stay one step ahead of your rivals. So playing online on our website will allow you to make a lot of money with professional bets to become a king. You can win this sports game and make money every day. This Matka app offers maximum security, 24/7 customer support and live chat options for players worldwide. 
                    <a href="#">Our website</a>
                    is one of the simplest sites for a live online game. So, play now and have unlimited fun!
                </p>
            </div>
        </div>
        <!-- faq -->
        <div class="container-fluid">
            <div class="faq">
                <h4>FAQ SECTION</h4>
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div id="headingOne" clasas="my-heading-faq" style="font-size: 20px;">
                            <a class="btn btn-link " data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" style="display: flex; justify-content: space-between; font-size: 20px;">
                                How can a player can guess Matka Jodi?
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">You can figure Satta Matka Jodi's number by computing the distinctive arrangement of numbers given by the coordinator. Likewise speculating of accurate number is relies on the kind of game-like open, close, Jodi, Sangam, bonanza, and some more. Here we will share a portion of the great stunts to track down the specific winning number that is the SECRET technique. </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingTwo" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="display: flex; justify-content: space-between; font-size: 20px;">
                                What is Matka?
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="card-body">Matka and Satta both are a kind of betting game which is played on the speculating of number. Matka is an old betting game played everywhere on the world. At first, it was played on the opening and shutting paces of cotton, where players put resources into the number in the wake of winning they win a hefty sum.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingThree" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style="display: flex; justify-content: space-between; font-size: 20px;">
                                How A Player Can play Kalyan game with maximum winnability?
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                            <div class="card-body">Kalyan game is played on numbers. In this game, you got three numbers from 0-9, and between (0-9)number you need to pick 3 numbers. Presently, for instance, you pick 2,9,4. Presently you need to make a computation with those three numbers to get the last number on which you will put away your cash.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingfour" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour" style="display: flex; justify-content: space-between; font-size: 20px;">
                                Is Matka Illegal in India?
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordionExample">
                            <div class="card-body">No, Matka isn't legal in Maharashtra and many other parts of India. As Matka is an illicit type of wagering or betting which is very well known in numerous areas of Maharashtra. Numerous paper additionally distribute article with respect to Matka result yet it was restricted by the Press Council of India for what it's worth illegal of Maharashtra.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingfive" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive" style="display: flex; justify-content: space-between; font-size: 20px;">
                                How to get Satta Numbers? 
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                            <div class="card-body">To get the winning Satta Matka number you need to do basic mathematical computation. The configuration of Satta Matka is exceptionally basic and you'll get it all over the place. You need to select one number from 0 to 9 and perform an estimation on that chose the number. Here is the reference, add three numbers you pick and figure as indicated by the stunt the last number you get is the subsequent number.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingfive" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive" style="display: flex; justify-content: space-between; font-size: 20px;">
                                What is Guessing Forum? 
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                            <div class="card-body">Guessing forum is the place where players can indulge in the speculating discussion we give you all the assistance expected to decide the speculating number.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingfive" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive" style="display: flex; justify-content: space-between; font-size: 20px;">
                                How one can learn Satta Matka? 
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                            <div class="card-body">There are various data hubs available on the web about the Satta Matka game knowledge base. you simply need to track down the best substance according to your game needs. </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingfive" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive" style="display: flex; justify-content: space-between; font-size: 20px;">
                                How to Find a Matka Jodi? 
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                            <div class="card-body">There is no precise equation to discover Matka Jodi, yet it is relying upon numbers. You simply need to figure the best arrangement of numbers. </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingfive" clasas="my-heading-faq">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive" style="display: flex; justify-content: space-between; font-size: 20px;">
                                What are the winnability Factors in Satta Matka? 
                                <span>
                                    <i class="fas fa-arrow-down"></i>
                                </span>
                            </a>
                        </div>
                        <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                            <div class="card-body">Satta Matka is a betting game that is very famous in India. Also, winning something major. Be that as it may, the triumphant systems are diverse as per various individuals. Some say it relies upon karma, some say it can get won by speculating the correct number. Also, a few say winning Satta Matka relies upon both karma and the correct speculating of the number. </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>
        <br>
    </div>
    <div class="my-btn">
        <a href="#top" class="gototop">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;">
        </a>
        <a href="https://api.whatsapp.com/send?phone=919339447115" class="whatapp">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;">
        </a>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="cssjs/p.js"></script>
    <script src="cssjs/bt.js"></script>
    <script src="cssjs/app.js"></script>
    <script type="text/javascript">
    function get_dates(market_id) {
        var date = document.getElementById('date').value;
        if (market_id == "" || market_id == null) {
            document.getElementById('lotterytimeerror').innerHTML = "Please select market!!";
            return
        }
        $.ajax({
            url: 'getdatebylotteryId.php?market_id=' + market_id + '&date=' + date,
            success: function(response) {
                var splited = response.split("|");
                var flag = splited[0];
                var dates = splited[1];
                if (flag != 1) {
                    document.getElementById('lotterytimeerror').innerHTML = "Today lottery play time is closed , you can play another day lottery.";
                    alert('Today lottery play time is closed , you can play another day lottery');
                    document.getElementById('date').innerHTML = dates
                } else {
                    document.getElementById('lotterytimeerror').innerHTML = "";
                    document.getElementById('date').innerHTML = dates
                }
            }
        })
    }
    </script>
</body>
</html>
