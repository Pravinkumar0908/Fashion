<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Online Matka Play Single Patti Play Online Matka Single</title>
<meta name="description" content="Online Matka Play Online single play full sangam half sangam and jodi" />

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="cssjs/bt.css">
<link rel="stylesheet" href="cssjs/style.css?v246">
<link rel="stylesheet" href="cssjs/single.css?v346">

</head>
<body>


<div id="#top"></div>
<div class="hea" style="height: 100px;"></div>
<div class="top-div fixed-top">
   

<nav class="navbar navbar-light bg-light d-flex jcc dsnfds"><a class="navbar-brand " href="index.php">
<img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
    border-radius: 9px;"></a>
<div class="d-flex djfk">
<a href="login.php" class="btn btn-warning">LOGIN</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span></button></div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
<li class="nav-item"><a class="nav-link" href="single.php">SINGLE</a></li>
<li class="nav-item"><a class="nav-link" href="jodi.php">JODI</a></li>
<li class="nav-item"><a class="nav-link" href="single-patti.php">SINGLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="double-patti.php">DOUBLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="half-sangam.php">HALF SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="full-sangam.php">FULL SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="star-line.php">STARLINE</a></li>
<li class="nav-item"><a class="nav-link" href="howtoplay.php">HOW TO PLAY</a></li>
<li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
<li class="nav-item"><a class="nav-link" href="register.php">REGISTER</a></li>
 </ul></div></nav>
   </div><div class="myform">
	<div class="container-fluid fdklslf">
	    			<h2 class="text-center">SINGLE (10 KA 873)</h2>
		<span id="lotterytimeerror" style="color:red;"></span>
		<h6>Select Your Game</h6>
		<form class="row" action="" method="POST" onsubmit="return confirm('Are You Sure ?\nOnce you Proceed You Cannot Revert.');">
			
			


<div class="form-group col-md-6 col-12">
			    
			    
			  <label for="market">SELECT YOUR MARKET</label>
			  <select class="form-control" id="market" name="market" required>
			      <option value=""> Select Market </option>
			      
			                                   
                                                                
                                                                    <option value="RAJDHANI_DAY_CLOSE">RAJDHANI DAY CLOSE (05:10 PM)</option>
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                    <option value="SUPREME_DAY_CLOSE">SUPREME DAY CLOSE (04:35 PM)</option>
                                                                                        
                                                                    <option value="KALYAN__OPEN" >KALYAN  OPEN (04:30 PM)</option>
                                                                
                                                                    <option value="KALYAN__CLOSE">KALYAN  CLOSE (06:30 PM)</option>
                                                                                        
                                                                    <option value="SRIDEVI_NIGHT__OPEN" >SRIDEVI NIGHT  OPEN (07:15 PM)</option>
                                                                
                                                                    <option value="SRIDEVI_NIGHT__CLOSE">SRIDEVI NIGHT  CLOSE (08:15 PM)</option>
                                                                                        
                                                                    <option value="SUPREME_NIGHT__OPEN" >SUPREME NIGHT  OPEN (08:35 PM)</option>
                                                                
                                                                    <option value="SUPREME_NIGHT__CLOSE">SUPREME NIGHT  CLOSE (10:35 PM)</option>
                                                                                        
                                                                    <option value="MILAN_NIGHT__OPEN" >MILAN NIGHT  OPEN (08:50 PM)</option>
                                                                
                                                                    <option value="MILAN_NIGHT__CLOSE">MILAN NIGHT  CLOSE (10:50 PM)</option>
                                                                                        
                                                                    <option value="RAJDHANI_NIGHT__OPEN" >RAJDHANI NIGHT  OPEN (09:10 PM)</option>
                                                                
                                                                    <option value="RAJDHANI_NIGHT__CLOSE">RAJDHANI NIGHT  CLOSE (11:10 PM)</option>
                                                                                        
                                                                    <option value="KALYAN_NIGHT__OPEN" >KALYAN NIGHT  OPEN (09:11 PM)</option>
                                                                
                                                                    <option value="KALYAN_NIGHT__CLOSE">KALYAN NIGHT  CLOSE (11:25 PM)</option>
                                                                                        
                                                                    <option value="MAIN_RATAN_OPEN" >MAIN RATAN OPEN (09:25 PM)</option>
                                                                
                                                                                        
                                                                    <option value="MAIN_BAZAR__OPEN" >MAIN BAZAR  OPEN (11:53 PM)</option>
                                                                
                                                                    <option value="MAIN_BAZAR__CLOSE">MAIN BAZAR  CLOSE (11:59 PM)</option>
                                                                                      
                                
				 			  </select>
			</div>
			
			
			<div class="form-group col-md-6 col-12">
		    <label for="date">SELECT DATE</label>
		    <select class="form-control" id="date" name="date" required>
			    <option value="26/10/2023">26/10/2023</option>
		    </select>
		  </div>
		  <div class="col-12 numa">
		  	<div class="row my-rrow label-sm-text">
		  		<div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num0">0</label>
				    <input type="number" class="form-control nnnd" min="10" id="num0" name="single0">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num1">1</label>
				    <input type="number" class="form-control nnnd" min="10" id="num1" name="single1">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num2">2</label>
				    <input type="number" class="form-control nnnd" min="10" id="num2" name="single2">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num3">3</label>
				    <input type="number" class="form-control nnnd" min="10" id="num3" name="single3">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num4">4</label>
				    <input type="number" class="form-control nnnd" min="10" id="num4" name="single4">
				  </div>
		  		<div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num5">5</label>
				    <input type="number" class="form-control nnnd" min="10" id="num1" name="single5">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num6">6</label>
				    <input type="number" class="form-control nnnd" min="10" id="num6" name="single6">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num7">7</label>
				    <input type="number" class="form-control nnnd" min="10" id="num7" name="single7">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num8">8</label>
				    <input type="number" class="form-control nnnd" min="10" id="num8" name="single8">
				  </div>
				  <div class="col-lg-3 col-md-4 my-sk col-6">
				    <label for="num9">9</label>
				    <input type="number" class="form-control nnnd" min="10" id="num9" name="single9">
				  </div>

		  	</div>
		  </div>
		  <div class="form-group col-12">
		  	<h5 class="shww">
		  		<span class="aa">Total Point :</span>
		  		<input type="hidden" name="total_point" id="total_point" value="">
		  		<span class="bb">00</span>
		  	</h5>
		  </div>
		
		  <div class="form-group col-12 justify-content-center d-flex">
												You Need to Login First.
						 					  </div>
		</form>
	</div>
</div>


<h3>DOWNLOAD THE GAME APP</h3> 
	<h3>AND START EARNING</h3>
	<div class="text-center mt-2 mb-2">
	    
	    <a href="https://matka.games/apk/online_matka_play.apk" class="btn btn-success" style="font-size: 25px;text-transform: uppercase;    background-image: linear-gradient(45deg, #E91E63, #F44336);    border-color: #fff;   border-radius: 10px;"> 
						<i class="fas fa-download"></i>
						<span>&nbsp;</span>
						<span>Download APP</span>
					</a>
	</div>
<div class="my-btn">
<a href="#top" class="gototop"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;"> </a>
<a href="https://api.whatsapp.com/send?phone=919339447115&amp;text=I%20have%20Some%20query%20Regarding%20onlinematkaplay.net" class="whatapp"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;"></a>





</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="cssjs/p.js"></script>
<script src="cssjs/bt.js"></script>
<script src="cssjs/app.js"></script>


<script>
$('.myform').on('input', '.nnnd', function(event) {
  var total = 0;
  $('.nnnd').each(function() {
    total += parseInt(this.value, 10) || 0;
  });
  $('.bb').html(total);
  document.getElementById("total_point").value = total;
})

$('.nnnd').bind('copy paste cut',function(e) {
  e.preventDefault();
});



</script>



</body>
</html>