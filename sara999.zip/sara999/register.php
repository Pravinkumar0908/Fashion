
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Online Matka Play Sign up</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



<link rel="stylesheet" href="cssjs/bt.css">
<link rel="stylesheet" href="cssjs/style.css?v46">
<link rel="stylesheet" href="cssjs/top.css?v46">

  



<style>

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
.container-fluid {
    width: 90%;
}
/*header end*/
.myform {
  margin-top: 50px;
}
.myform h3 {
  font-weight: 700;
  text-align: center;
}
.fdjs {
    text-align: center;
}
.fdklslf {
width: 50%;
    background: linear-gradient(64deg,#011557 50%,#051f75 50%);
    box-shadow: 0 0 10px -3px #000;
    margin-top: 30px;
    padding: 16px 40px;
    border-radius: 20px 20px 0 0;
    border: 1px solid #21ebff;
}
.myform {
    margin-bottom: 40px;
}
.myform h2 {
  background-image: linear-gradient(0deg,#ff9700 0,#fb4b02 100%);
    color: #fff;
    text-shadow: 1px 1px 2px #777;
    border-radius: 20px 0 20px 0;
    padding: 10px 0;
    text-align: center;
}
.myform h6 {
    font-weight: 600;
    font-size: 22px;
    margin: 20px 0;
}
.shww {
text-transform: uppercase;
    font-weight: 600;
    text-align: center;
    margin: 20px 0;
    font-size: 32px;
}

.kls>div {
    margin-bottom: 20px;
}
.btnaa {
    text-align: center;
}
input {
      /*border: 1px solid #2196F3 !important;*/
    /*border-radius: 0 !important;*/
    opacity: 1;
    
}
.btnaa a {
       width: 200px;
    margin: 9px 0 0;
    background-color: #3F51B5;
}
div.fp {
        margin-bottom: 10px;
}

.fp a {
color: #2196F3;
    font-weight: 700;
    font-size: 17px;
}
.rn {
    font-size: 17px;
    
}
.rn a {
    font-weight: 700;
    color: black;
    
}
input {
    border: 1px solid #2196F3 !important;
    border-radius: 0 !important;
}
.kls label:not(.mnbv) {
color: #fff;
    margin-bottom: 0;
    width: 100%;
    font-size: 20px;
    font-weight: 700;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.labein {
    display: -webkit-flex;
    display: -moz-flex;
    display: -ms-flex;
    display: -o-flex;
    display: block;
}

#form1 {
    color: white;
}




@media only screen and (max-width: 768px) {
.myds {
    height: 33px !important;
}
/*header*/
.navbar-toggler {
    display: block;
    background-color: white;
}
.djfk button,
.djfk a {
    margin-left: 10px;
}
.dfkjd {
    padding:0 20px;
}
.header {
    padding-top: 120px;
    padding-bottom: 120px;
}
.dfkjd .nav-link {
    padding-left: 10px;
}
/*header*/
.fdklslf {
    width: 70%;
}
} /*media qweuy end*/
@media only screen and (max-width: 500px) {
/*header*/
.djfk {
    display: flex !important;
}
.djfk button,
.djfk a {
    padding: 3px 4px !important;
    font-size: 13px;
}
a.btn.btn-primary.gfdn {
    margin-left: 0;
}
.myvid {
    width: 100%;
    margin: 20px auto;
}
.myform h5 {
    font-size: 14px;
    line-height: 1.4;
}
/*header*/
.fdklslf {
    width: 95%;
    padding-left: 20px;
    padding-right: 20px;
}
.footer a {
    font-size: 12px;
}
} /*media qweuy end*/
@media only screen and (max-width: 320px) {
.fdklslf {
    margin-top: 70px;
}
}
/*emd -------------*/


.btn.btn-sucess {
  color: #fff;
    background: black;
    border-color: #051f75 !important;
    padding: 10px 25px !important;
    opacity: 1;
    border-radius: 24px !important;
}
#form1 {
    padding-top: 20px;
}

.row input {
    text-align: left;
    padding-left: 5px !important;
}
</style>
</head>
<body>

<div id="#top"></div>
<div class="hea" style="height: 100px;"></div>
<div class="top-div fixed-top">

   

<nav class="navbar navbar-light bg-light d-flex jcc dsnfds"><a class="navbar-brand " href="index.php">
<img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
    border-radius: 9px;"></a>
<div class="d-flex djfk">
<a href="login.php" class="btn btn-warning">LOGIN</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span></button></div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
<li class="nav-item"><a class="nav-link" href="single.php">SINGLE</a></li>
<li class="nav-item"><a class="nav-link" href="jodi.php">JODI</a></li>
<li class="nav-item"><a class="nav-link" href="single-patti.php">SINGLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="double-patti.php">DOUBLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="half-sangam.php">HALF SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="full-sangam.php">FULL SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="star-line.php">STARLINE</a></li>
<li class="nav-item"><a class="nav-link" href="howtoplay.php">HOW TO PLAY</a></li>
<li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
<li class="nav-item"><a class="nav-link" href="register.php">REGISTER</a></li>
 </ul></div></nav>
   </div>


<div class="myform login">
	<div class="container-fluid fdklslf">
		<h2>User Registration</h2>
				<form class="row kls" nname="form1" id="form1" action="" method="post">
		    <div class="col-12 bbb labein">
				<label for="number">Mobile Number</label>
				<input type="text" class="form-control" name="mobile" maxlength="10" minlength="10" value="" required>
			</div>
		
			<div class="col-12 aaa labein">
				<label for="username">Username</label>
				<input type="text" class="form-control" id="username" name="name" maxlength="25" minlength="4" required>
			</div>
			<div class="col-12 bbb labein">
				<label for="password">Password</label>
				<input type="password" class="form-control" id="password" name="pass" required>
			</div>
			
			<div class="col-12 rn">
				<input type="checkbox" class="custom-checkbox" id="checkb" required>
				<label for="checkb" class="mnbv">I agree to </label>
				<a href="#" class="">Terms and Conditions</a>
			</div>
			<div class="col-12 btnaa">
				<input type="submit" class="btn btn-sucess" name="signup" value="REGISTER">
			</div>
		</form>
	</div>
</div>




<div class="my-btn">
<a href="#top" class="gototop"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;"> </a>
<a href="https://api.whatsapp.com/send?phone=919339447115&amp;text=I%20have%20Some%20query%20Regarding%20onlinematkaplay.net" class="whatapp"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;"></a>





<!--<div class="down-div"> 
<a href="https://matka.games/apk/online_matka_play.apk" class="download-app"> 
<span>
<i class="fas fa-download"></i>&nbsp;&nbsp;Download Android App
</span>
</a>
</div>-->


</div>



<script> 
if ('serviceWorker' in navigator) {
    console.log("Will the service worker register?");
    navigator.serviceWorker.register('service-worker.js')
        .then(function(reg) {
            console.log("Yes, it did.");
        }).catch(function(err) {
            console.log("No it didn't. This happened:", err)
        });
}
 
</script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="cssjs/p.js"></script>
<script src="cssjs/bt.js"></script>
<script src="cssjs/app.js"></script>
<script type="text/javascript">
function get_dates(market_id){var date=document.getElementById('date').value; if(market_id=="" || market_id==null){document.getElementById('lotterytimeerror').innerHTML="Please select market!!";return}$.ajax({url: 'getdatebylotteryId.php?market_id=' + market_id +'&date=' + date,success: function(response){var splited=response.split("|");var flag=splited[0];var dates=splited[1];if(flag !=1){document.getElementById('lotterytimeerror').innerHTML="Today lottery play time is closed , you can play another day lottery."; alert('Today lottery play time is closed , you can play another day lottery');document.getElementById('date').innerHTML=dates}else{document.getElementById('lotterytimeerror').innerHTML=""; document.getElementById('date').innerHTML=dates}}})}
</script>
 <script src="https://matka.games/cssjs/jquery.validate.min.js"></script>
  <script>
    setTimeout(function(){
	$("#resend_otp").show();},20000);
  </script>
  
</body>
</html>