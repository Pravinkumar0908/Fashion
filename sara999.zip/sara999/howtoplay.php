<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>how to play </title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="img/favicon.ico">

<link rel="stylesheet" href="cssjs/bt.css">
<link rel="stylesheet" href="cssjs/style.css?v46">
<link rel="stylesheet" href="cssjs/top.css?v46">


  

<style>
.container-fluid {
	width: 90%;
}
/*header end*/
.myform {
  margin-top: 50px;
}
.myform h3 {
  font-weight: 700;
  text-align: center;
}
.fdjs {
    text-align: center;
}
.fdklslf {
        width: 99%;
    background-color: #f4f4f4;
    box-shadow: 0 0 10px -3px #000;
    margin-top: 30px;
    padding: 16px 20px;
    border-radius: 20px;
}
.myform {
    margin-bottom: 40px;
}
.myform h2 {
    text-align: center;
    font-weight: 700;
    border-bottom: 2px solid #3f51b5;
    color: #3f51b5;
    padding-bottom: 17px;
    padding-top: 33px;
}
.myform h6 {
    font-weight: 600;
    font-size: 22px;
    margin: 20px 0;
}
.shww {
text-transform: uppercase;
    font-weight: 600;
    text-align: center;
    margin: 20px 0;
    font-size: 32px;
}
.gototop:hover {
    color: #fff;
}
.gototop {
    position: fixed;
    right: 20px;
    bottom: 100px;
    background-color: #3f51b5;
    padding: 5px 12px;
    border-radius: 80px;
    font-size: 22px;
    box-shadow: 0 0 10px #000;
    color: #fff;
}
.whatapp:hover {
    color: #fff;
} 
.whatapp {
    position: fixed;
    right: 20px;
    bottom: 40px;
    background-color: #3ca240;
    padding: 5px 12px;
    border-radius: 80px;
    font-size: 22px;
    box-shadow: 0 0 10px #000;
    color: #fff;
}
.myvid {
       width: 57%;
    display: flex;
    margin: 20px auto;
    border: 4px solid #3F51B5;
    background-color: #3F51B5;
    box-shadow: 0 0 10px -2px #000;
}
.myform h5 {
    font-size: 15px;
    font-weight: 500;
    text-transform: capitalize;
    padding-bottom: 50px;
    padding-top: 15px;
    opacity:0.6;
}
.myform h4 {
font-size: 16px;
    font-weight: 700;
    color: navy;
}
.kdh {
    color: #3f51b5;
}











@media only screen and (max-width: 768px) {
.myds {
    height: 33px !important;
}
/*header*/
.navbar-toggler {
    display: block;
    background-color: white;
}
.djfk button,
.djfk a {
    margin-left: 10px;
}
.dfkjd {
    padding:0 20px;
}
.header {
    padding-top: 120px;
    padding-bottom: 120px;
}
.dfkjd .nav-link {
    padding-left: 10px;
}
/*header*/
} /*media qweuy end*/
@media only screen and (max-width: 500px) {
/*header*/
.djfk {
    display: flex !important;
}
.djfk button,
.djfk a {
    padding: 3px 4px !important;
    font-size: 13px;
}
a.btn.btn-primary.gfdn {
    margin-left: 0;
}
.myvid {
    width: 100%;
    margin: 20px auto;
}
.myform h5 {
    font-size: 14px;
    line-height: 1.4;
}
/*header*/
.footer a {
    font-size: 12px;
}
} /*media qweuy end*/
@media only screen and (max-width: 320px) {
.fdklslf {
    margin-top: 70px;
}
}
/*emd -------------*/
</style>
</head>
<body>
<div id="#top"></div>
<div class="hea" style="height: 100px;"></div>
<div class="top-div fixed-top">

   

<nav class="navbar navbar-light bg-light d-flex jcc dsnfds"><a class="navbar-brand " href="index.php">
<img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
    border-radius: 9px;"></a>
<div class="d-flex djfk">
<a href="login.php" class="btn btn-warning">LOGIN</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span></button></div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
<li class="nav-item"><a class="nav-link" href="single.php">SINGLE</a></li>
<li class="nav-item"><a class="nav-link" href="jodi.php">JODI</a></li>
<li class="nav-item"><a class="nav-link" href="single-patti.php">SINGLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="double-patti.php">DOUBLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="half-sangam.php">HALF SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="full-sangam.php">FULL SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="star-line.php">STARLINE</a></li>
<li class="nav-item"><a class="nav-link" href="howtoplay.php">HOW TO PLAY</a></li>
<li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
<li class="nav-item"><a class="nav-link" href="register.php">REGISTER</a></li>
 </ul></div></nav>
   
   </div><div class="myform">
	<div class="container-fluid fdklslf">
		<h2 class="text-center">HOW TO PLAY MATKA ONLINE</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/Ly1il8sUn2A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		<h5>Online Game Khelne Ke Liye Sabse Pehle Aap Hume Paise Deposit Karwaye, Minimum Amount 500 Usse Kam Deposit Nahi Liya Jata, Uske Baad Aap Jitne Paise Hume Deposit Karwayenge Utne Point Aapki User Id Me Add Kar Diye Jaayenge.</h5>

		<h2>1 Rs.==1 POINT</h2>
		<h5>Jo Game Aap Khelenge Agar Aap Ka Game Lagta Hai To Aapke Points Automatically Badh Jaayenge, And Jab Aapko Payment Chahiye Ho Tab Aap Hume Call Ya Messege Karke Inform Kare, Jisse Ki Hum Aapke A/c Me Payment Tranfer Kar Sake.</h5>
		<h5>Bet Karne Ka Minimum Amount 10 Rs.usse Kam Se Game Na Khele. Kisi Help And A/c Me Paise Deposit Karwane Ke Liye Aap Hum Neeche Diye Gaye Numbers Par Contact Kare…..</h5>
		<h4>THNXXXX REGARDS</h4>

		<h2>MATKA PLAY GROUP</h2>
		<h3>HOW TO PLAY MATKA ONLINE</h3>
		<h5>1. First of all Kindly Deposit money to our a/c.</h5>
		<h5>2. Minimum Deposit Of Rs 500 Rs., Below 500 Rs. Will Not Be Accepted .</h5>
		<h5>3. Secondly The Amount Of Money You Deposit Accordingly The Points Will Be Added To Your Corresponding Id</h5>

		<h3>1 Rs.==1 POINT</h3>
		<p>Minimum amount to bet is Rs. 10.</p>
		<h5>3. The Game You Played And Got Lucky Enough To Win It Then Accordingly Your Points Will Be Increased.</h5>
		<h5>4. If You Wish To Encash The Points Of Your Id Then Kindly Call Or Message Us And Your Money Will Be Transferred To Your Account As Soon As</h5>
		<h5>**In Case Of Any Inconvenience Regarding The Transaction Of Money Or Further Query Then You Can Contact Us On The Following Numbers.</h5>

		<h4>THNXXXX REGARDS</h4>

		<h3 class="kdh">MATKA PLAY GROUP</h3>


	</div>
	<h3 class="mt-4">DOWNLOAD THE GAME APP</h3>
	<h3>AND START EARNING</h3>
	<div class="text-center mt-2 mb-2">
		<a href="#" class="btn btn-primary">DOWNLOAD APP</a>
	</div>
</div>



<div class="my-btn">
<a href="#top" class="gototop"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;"> </a>
<a href="https://api.whatsapp.com/send?phone=919339447115&amp;text=I%20have%20Some%20query%20Regarding%20onlinematkaplay.net" class="whatapp"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;"></a>





<!--<div class="down-div"> 
<a href="https://matka.games/apk/online_matka_play.apk" class="download-app"> 
<span>
<i class="fas fa-download"></i>&nbsp;&nbsp;Download Android App
</span>
</a>
</div>-->


</div>



<script> 
if ('serviceWorker' in navigator) {
    console.log("Will the service worker register?");
    navigator.serviceWorker.register('service-worker.js')
        .then(function(reg) {
            console.log("Yes, it did.");
        }).catch(function(err) {
            console.log("No it didn't. This happened:", err)
        });
}
 
</script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="cssjs/p.js"></script>
<script src="cssjs/bt.js"></script>
<script src="cssjs/app.js"></script>
<script type="text/javascript">
function get_dates(market_id){var date=document.getElementById('date').value; if(market_id=="" || market_id==null){document.getElementById('lotterytimeerror').innerHTML="Please select market!!";return}$.ajax({url: 'getdatebylotteryId.php?market_id=' + market_id +'&date=' + date,success: function(response){var splited=response.split("|");var flag=splited[0];var dates=splited[1];if(flag !=1){document.getElementById('lotterytimeerror').innerHTML="Today lottery play time is closed , you can play another day lottery."; alert('Today lottery play time is closed , you can play another day lottery');document.getElementById('date').innerHTML=dates}else{document.getElementById('lotterytimeerror').innerHTML=""; document.getElementById('date').innerHTML=dates}}})}
</script><script>
$('.myform').on('input', '.nnnd', function(event) {
  var total = 0;
  $('.nnnd').each(function() {
    total += parseInt(this.value, 10) || 0;
  });
  $('.bb').html(total);
})
</script>

<script src="cssjs/app.js"></script>
</body>
</html>