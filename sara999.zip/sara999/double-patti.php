<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Online Matka Play Double Patti PLay Double Panna Penal</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="cssjs/bt.css">
<link rel="stylesheet" href="cssjs/style.css?v246">
<link rel="stylesheet" href="cssjs/top.css?v46">



  

<style>
.container-fluid {
	width: 95%;
}
/*header end*/
.gototop:hover {
    color: #fff;
}
.gototop {
  position: fixed;
    right: 20px;
    bottom: 100px;
    background: linear-gradient(0deg,#ff9700 0,#fb4b02 100%);
    padding: 12px;
    border-radius: 80px;
    font-size: 12px;
    box-shadow: 0 0 10px #000;
    color: #fff;
}
.whatapp:hover {
    color: #fff;
} 
.whatapp {
  position: fixed;
    right: 20px;
    bottom: 40px;
    background-color: #00e209;
    padding: 12px;
    border-radius: 80px;
    font-size: 12px;
    box-shadow: 0 0 10px #000;
    color: #fff;
}
/*myform*/
.myform {
    padding-top: 20px;
    margin-top: 40px;
}
.myform h3 {
  font-weight: 700;
  color: #fff;
  text-align: center;
}
.fdklslf {
    background: linear-gradient(64deg,#011557 50%,#051f75 50%);
    box-shadow: 0 0 10px -3px #000;
    margin-top: 30px;
    padding: 16px 20px;
    border-radius: 20px 20px 0 0;
    border: 1px solid #21ebff;
    margin-bottom: 40px;
}
.myform h2 {
  background-image: linear-gradient(0deg,#ff9700 0,#fb4b02 100%);
    color: #fff;
    text-shadow: 1px 1px 2px #777;
    border-radius: 20px 0 20px 0;
    padding: 10px 0;
}
.myform h6 {
    font-weight: 600;
    font-size: 22px;
    margin: 20px 0;
}
.form-group label {
    display: inline-block;
    margin-bottom: .5rem;
    background-color: #007bff;
    color: #fff;
    text-align: center;
    width: 100%;
    margin-bottom: 0;
    padding: 10px 0;
}

.numa .row>div {
    margin-bottom: 15px;
}
.numa input {
    border-radius: 0;
}



.shww {
    text-transform: uppercase;
    font-weight: 600;
    text-align: center;
    margin: 20px 0;
    font-size: 32px;
}
.shww .bb {
    color: #007bff;
}

@media only screen and (max-width: 768px) {
/*header*/
.navbar-toggler {
    display: block;
    background-color: white;
}
.djfk button,
.djfk a {
    margin-left: 10px;
}
.dfkjd {
    padding:0 20px;
}
.header {
    padding-top: 120px;
    padding-bottom: 120px;
}
.dfkjd .nav-link {
    padding-left: 10px;
}
/*header*/
.myform {
    margin-top: 0px;
}
} /*media qweuy end*/
@media only screen and (max-width: 500px) {
/*header*/
.djfk {
    display: flex !important;
}
.djfk button,
.djfk a {
    padding: 3px 4px !important;
    font-size: 13px;
}
a.btn.btn-primary.gfdn {
    margin-left: 0;
}
.list-ul {
    width: 100%;
}
/*header*/
.numa .row {
    margin-left: 0;
    margin-right: 0;
}
.numa .row>div {
    padding-left: 5px;
    padding-right: 5px;
}
.numa .row>div:nth-child(1) ,
.numa .row>div:nth-child(7) {
    padding-left: 0px;
}
.numa .row>div:nth-child(6) ,
.numa .row>div:nth-child(12) {
    padding-right: 0px;
}
.footer a {
    font-size: 12px;
}
} /*media qweuy end*/
/*emd -------------*/



input[type="number"] {
    -moz-appearance: textfield;
}

.my-rrow input {
    width: 70%;
}

.row input {
    text-align: center;
    padding-left: 0 !important;
    padding-right: 0 !important;
    height: auto !important;
    border-radius: 0;
}

.my-rrow {
    margin-right: -1px !important;
    margin-left: -1px !important;
}


.my-rrow > div {
    padding-left: 1px !important;
    padding-right: 1px !important;
}

.my-sk {
display: -webkit-flex;
display: -moz-flex;
display: -ms-flex;
display: -o-flex;
display: flex;
}
.my-sk input {
	height: auto;
}


</style>
</head>
<body>

<div id="#top"></div>
<div class="hea" style="height: 100px;"></div>
<div class="top-div fixed-top">   


<nav class="navbar navbar-light bg-light d-flex jcc dsnfds"><a class="navbar-brand " href="index.php">
<img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
    border-radius: 9px;"></a>
<div class="d-flex djfk">
<a href="login.php" class="btn btn-warning">LOGIN</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span></button></div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
<li class="nav-item"><a class="nav-link" href="single.php">SINGLE</a></li>
<li class="nav-item"><a class="nav-link" href="jodi.php">JODI</a></li>
<li class="nav-item"><a class="nav-link" href="single-patti.php">SINGLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="double-patti.php">DOUBLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="half-sangam.php">HALF SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="full-sangam.php">FULL SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="star-line.php">STARLINE</a></li>
<li class="nav-item"><a class="nav-link" href="howtoplay.php">HOW TO PLAY</a></li>
<li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
<li class="nav-item"><a class="nav-link" href="register.php">REGISTER</a></li>
 </ul></div></nav>
</div>


<div class="myform">

	<div class="container-fluid fdklslf">
	    		<h2 class="text-center">DOUBLE PATTI (10 KA 31500)</h2>
		<span id="lotterytimeerror" style="color:red;"></span>
		<h6>Select Your Game</h6>
		<form class="row" action="" method="POST" onsubmit="return confirm('Are You Sure ?\nOnce you Proceed You Cannot Revert.');"> 
			


<div class="form-group col-md-6 col-12">
			    
			    
			  <label for="market">SELECT YOUR MARKET</label>
			  <select class="form-control" id="market" name="market" required>
			      <option value=""> Select Market </option>
			  			                                 
                                                                
                                                                    <option value="RAJDHANI_DAY_CLOSE">RAJDHANI DAY CLOSE (05:10 PM)</option>
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                                        
                                                                
                                                                    <option value="SUPREME_DAY_CLOSE">SUPREME DAY CLOSE (04:35 PM)</option>
                                                                                        
                                                                    <option value="KALYAN__OPEN" >KALYAN  OPEN (04:30 PM)</option>
                                                                
                                                                    <option value="KALYAN__CLOSE">KALYAN  CLOSE (06:30 PM)</option>
                                                                                        
                                                                    <option value="SRIDEVI_NIGHT__OPEN" >SRIDEVI NIGHT  OPEN (07:15 PM)</option>
                                                                
                                                                    <option value="SRIDEVI_NIGHT__CLOSE">SRIDEVI NIGHT  CLOSE (08:15 PM)</option>
                                                                                        
                                                                    <option value="SUPREME_NIGHT__OPEN" >SUPREME NIGHT  OPEN (08:35 PM)</option>
                                                                
                                                                    <option value="SUPREME_NIGHT__CLOSE">SUPREME NIGHT  CLOSE (10:35 PM)</option>
                                                                                        
                                                                    <option value="MILAN_NIGHT__OPEN" >MILAN NIGHT  OPEN (08:50 PM)</option>
                                                                
                                                                    <option value="MILAN_NIGHT__CLOSE">MILAN NIGHT  CLOSE (10:50 PM)</option>
                                                                                        
                                                                    <option value="RAJDHANI_NIGHT__OPEN" >RAJDHANI NIGHT  OPEN (09:10 PM)</option>
                                                                
                                                                    <option value="RAJDHANI_NIGHT__CLOSE">RAJDHANI NIGHT  CLOSE (11:10 PM)</option>
                                                                                        
                                                                    <option value="KALYAN_NIGHT__OPEN" >KALYAN NIGHT  OPEN (09:11 PM)</option>
                                                                
                                                                    <option value="KALYAN_NIGHT__CLOSE">KALYAN NIGHT  CLOSE (11:25 PM)</option>
                                                                                        
                                                                    <option value="MAIN_RATAN_OPEN" >MAIN RATAN OPEN (09:25 PM)</option>
                                                                
                                                                                        
                                                                    <option value="MAIN_BAZAR__OPEN" >MAIN BAZAR  OPEN (11:53 PM)</option>
                                                                
                                                                    <option value="MAIN_BAZAR__CLOSE">MAIN BAZAR  CLOSE (11:59 PM)</option>
                                                            				 			  </select>
			</div>
			
			
			<div class="form-group col-md-6 col-12">
		    <label for="date">SELECT DATE</label>
		    <select class="form-control" id="date" name="date" required>
			 <option value="26/10/2023">26/10/2023</option>
		    </select>
		  </div>

			<div class="form-group col-12 numa">
				<label class="text-center numb">1</label>
				<div class="row my-rrow label-sm-text">
				                				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>100</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_100">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>119</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_119">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>155</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_155">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>227</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_227">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>335</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_335">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>344</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_344">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>399</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_399">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>588</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_588">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>669</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_669">
    					</div>
    									</div>
			</div>
			<!-- 02 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">2</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>110</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_110">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>200</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_200">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>228</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_228">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>255</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_255">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>336</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_336">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>499</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_499">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>660</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_660">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>688</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_688">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>778</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_778">
    					</div>
    									</div>
			</div>
			<!-- 03 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">3</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>166</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_166">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>229</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_229">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>300</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_300">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>337</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_337">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>355</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_355">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>445</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_445">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>599</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_599">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>779</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_779">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>788</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_788">
    					</div>
    									</div>
			</div>
			<!-- 04 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">4</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>112</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_112">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>220</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_220">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>266</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_266">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>338</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_338">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>400</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_400">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>446</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_446">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>455</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_455">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>699</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_699">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>770</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_770">
    					</div>
    									</div>
			</div>
			<!-- 05 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">5</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>113</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_113">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>122</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_122">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>177</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_177">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>339</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_339">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>366</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_366">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>447</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_447">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>500</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_500">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>799</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_799">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>889</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_889">
    					</div>
    									</div>
			</div>
			<!-- 06 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">6</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>114</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_114">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>277</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_277">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>330</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_330">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>448</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_448">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>466</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_466">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>556</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_556">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>600</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_600">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>880</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_880">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>899</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_899">
    					</div>
    									</div>
			</div>
			<!-- 07 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">7</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>115</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_115">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>133</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_133">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>188</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_188">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>223</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_223">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>377</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_377">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>449</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_449">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>557</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_557">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>566</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_566">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>700</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_700">
    					</div>
    									</div>
			</div>
			<!-- 08 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">8</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>116</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_116">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>224</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_224">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>233</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_233">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>288</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_288">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>440</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_440">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>477</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_477">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>558</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_558">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>800</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_800">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>990</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_990">
    					</div>
    									</div>
			</div>
			<!-- 09 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">9</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>117</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_117">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>144</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_144">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>199</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_199">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>225</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_225">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>388</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_388">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>559</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_559">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>577</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_577">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>667</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_667">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>900</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_900">
    					</div>
    									</div>
			</div>
			<!-- 0 -->
			<div class="form-group col-12 numa">
				<label class="text-center numb">0</label>
				<div class="row my-rrow label-sm-text">
					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>118</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_118">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>226</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_226">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>244</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_244">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>299</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_299">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>334</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_334">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>488</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_488">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>550</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_550">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>668</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_668">
    					</div>
    					        				<div class="col-lg-3 col-md-4 my-sk col-6">
    						<label>677</label>
    						<input type="number" class="form-control nnnd" min="10" name="double_patti_677">
    					</div>
    									</div>
			</div>
		  <div class="form-group col-12">
		  	<h5 class="shww">
		  		<span class="aa">Total Point :</span>
		  		<span class="bb">00</span>
		  		<input type="hidden" name="total_point" id="total_point" value="">
		  	</h5>
		  </div>
		  <div class="form-group col-12 justify-content-center d-flex">
		      									You Need to Login First.
						 					  </div>
		</form>
	</div>



<h3>DOWNLOAD THE GAME APP</h3> 
	<h3>AND START EARNING</h3>
	<div class="text-center mt-2 mb-2">
	    
	    <a href="https://matka.games/apk/online_matka_play.apk" class="btn btn-success" style="font-size: 25px;text-transform: uppercase;    background-image: linear-gradient(45deg, #E91E63, #F44336);    border-color: #fff;   border-radius: 10px;"> 
						<i class="fas fa-download"></i>
						<span>&nbsp;</span>
						<span>Download APP</span>
					</a>
	</div>

<div class="my-btn">
<a href="#top" class="gototop"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;"> </a>
<a href="https://api.whatsapp.com/send?phone=919339447115&amp;text=I%20have%20Some%20query%20Regarding%20onlinematkaplay.net" class="whatapp"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;"></a>





<!--<div class="down-div"> 
<a href="https://matka.games/apk/online_matka_play.apk" class="download-app"> 
<span>
<i class="fas fa-download"></i>&nbsp;&nbsp;Download Android App
</span>
</a>
</div>-->


</div>



<script> 
if ('serviceWorker' in navigator) {
    console.log("Will the service worker register?");
    navigator.serviceWorker.register('service-worker.js')
        .then(function(reg) {
            console.log("Yes, it did.");
        }).catch(function(err) {
            console.log("No it didn't. This happened:", err)
        });
}
 
</script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="cssjs/p.js"></script>
<script src="cssjs/bt.js"></script>
<script src="cssjs/app.js"></script>
<script type="text/javascript">
function get_dates(market_id){var date=document.getElementById('date').value; if(market_id=="" || market_id==null){document.getElementById('lotterytimeerror').innerHTML="Please select market!!";return}$.ajax({url: 'getdatebylotteryId.php?market_id=' + market_id +'&date=' + date,success: function(response){var splited=response.split("|");var flag=splited[0];var dates=splited[1];if(flag !=1){document.getElementById('lotterytimeerror').innerHTML="Today lottery play time is closed , you can play another day lottery."; alert('Today lottery play time is closed , you can play another day lottery');document.getElementById('date').innerHTML=dates}else{document.getElementById('lotterytimeerror').innerHTML=""; document.getElementById('date').innerHTML=dates}}})}
</script>

<script>
$('li').click(function() {
    $(this).toggleClass("selected");
}); 
$('li').click(function(e){ //on add input button click
	// e.preventDefault();
	// if(x < max_fields){ //max input box allowed
		// x++; //text box increment
		$('.input-fields').append(`
			<div class="dynamic-input col-md-2 col-3">
				<label>num</label>
				<input type="number" name="number[]"/>
				<a class="delete">x</a>
			</div>
		`); //add input box
	
});



$('.myform').on('input', '.nnnd', function(event) {
  var total = 0;
  $('.nnnd').each(function() {
    total += parseInt(this.value, 10) || 0;
  });
  $('.bb').html(total);
  document.getElementById("total_point").value = total;
})

$('.nnnd').bind('copy paste cut',function(e) {
  e.preventDefault();
});
</script>
</body>
</html>