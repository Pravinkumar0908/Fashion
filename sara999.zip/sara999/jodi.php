<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Online Matka Play Online Matka Play - Jodi Play </title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="cssjs/bt.css">
<link rel="stylesheet" href="cssjs/style.css?v46">
<link rel="stylesheet" href="cssjs/top.css?v46">


<style>

.container-fluid {
	width: 95%;
}
/*header end*/

/*myform*/
.myform {
    padding-top: 20px;
}
.myform h3 {
  font-weight: 700;
  text-align: center;
  color: #fff;
}
.fdklslf {
  background: linear-gradient(64deg,#011557 50%,#051f75 50%);
    box-shadow: 0 0 10px -3px #000;
    margin-top: 30px;
    padding: 16px 20px;
    border-radius: 20px 20px 0 0;
    margin-bottom: 40px;
    border: 1px solid #21ebff;
}
.myform h2 {
  background-image: linear-gradient(0deg,#ff9700 0,#fb4b02 100%);
    color: #fff;
    text-shadow: 1px 1px 2px #777;
    border-radius: 20px 0 20px 0;
    padding: 10px 0;
}
.myform h6 {
    font-weight: 600;
    font-size: 22px;
    margin: 20px 0;
}
.form-group> label {
    display: inline-block;
    margin-bottom: .5rem;
    background-color: #007bff;
    color: #fff;
    text-align: center;
    width: 100%;
    margin-bottom: 0;
    padding: 10px 0;
}
.list-ul {
    padding: 5px 0;
    overflow-y: auto;
    height: 250px;
        width: 50%;
    margin: 20px auto;
}
.list-ul li {
    font-size: 20px;
    font-weight: 700;
    padding: 3px 25px;
    transition: all .1s;
}
.list-ul li:hover {
    background-color: #051f75;
    color: #fff;
}
.selected {
    background-color: #011557 !important;
    color: #fff;
}
.dynamic-input {

margin-bottom: 10px;
}
.dynamic-input label {
    display: block;
    background-color: #007bff;
    color: #fff;
    padding: 3px 0;
    text-align: center;
    width: 100%;
    margin-bottom: 0;
}
.dynamic-input input {
    width: 100%;
    display: block;
text-align: center;
}
.dynamic-input a {
    width: 100%;
    display: block;
    background: linear-gradient(45deg, #ff0101, #011557);
    padding: 3px 0;
    text-align: center;
    color: #fff;
    font-weight: 700;
    cursor: pointer;

}
.dynamic-input a:hover {
  background: linear-gradient(45deg, #ff0101, #ff0101);
    color: #fff;
}

.dynamic-input {
    /*display: none;*/
    margin-bottom: 10px;
}
.show-div {
    display: block;
}
/*danger alert*/
#myElem {
	    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 9999;
}
#myElem::after {
	background-color: #fff;
}
.hide-div {
	display: none;
}
.show-div {
    display: -webkit-flex;
    display: -moz-flex;
    display: -ms-flex;
    display: -o-flex;
    display: flex;
}
/*danger alert*/
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
 /* margin: 0;*/
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}

.row.input-fields {
    background-color: #5468ff;
    padding: 10px 0 0;
    margin: 0;
    border: 1px solid #b3b3b3;
    border-radius: 10px;
}

.shww {
    text-transform: uppercase;
    font-weight: 600;
    text-align: center;
    margin: 20px 0;
    font-size: 32px;
}
.shww .bb {
    color: #007bff;
}


/*header*/
.navbar-toggler {
    display: block;
    background-color: white;
}
.djfk button,
.djfk a {
    margin-left: 10px;
}
.dfkjd {
    padding:0 20px;
}
.header {
    padding-top: 120px;
    padding-bottom: 120px;
}
.dfkjd .nav-link {
    padding-left: 10px;
}
/*header*/
.hea {
	height: 46px !important;
}
} /*media qweuy end*/

.hea {
	height: 50px !important;
}
/*header*/
.djfk {
    display: flex !important;
}
.djfk button,
.djfk a {
    padding: 3px 4px !important;
    font-size: 13px;
}
a.btn.btn-primary.gfdn {
    margin-left: 0;
}
.list-ul {
    width: 100%;
}
/*header*/
.input-fields {
    padding-left: 15px;
    padding-right: 15px;
}
.dynamic-input {
    padding-left: 5px;
    padding-right: 5px;
}
.footer a {
    font-size: 12px;
}
.myform label {
	font-size: 13px;
}
.container-fluid.fdklslf {
	width: 95%;
}
} /*media qweuy end*/
/*emd -------------*/
</style>
</head>
<body>
<div id="#top"></div>
<div class="hea" style="height: 100px;"></div>
<div class="top-div fixed-top">
   

<nav class="navbar navbar-light bg-light d-flex jcc dsnfds"><a class="navbar-brand " href="index.php">
<img src="img/main_home_logo.png" style="width: 120px;border: solid 2px #fff;background: #fff;
    border-radius: 9px;"></a>
<div class="d-flex djfk">
<a href="login.php" class="btn btn-warning">LOGIN</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span></button></div>
</nav>
<nav class="navbar navbar-expand-lg navbar-light bg-light dfkjd">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
<li class="nav-item"><a class="nav-link" href="single.php">SINGLE</a></li>
<li class="nav-item"><a class="nav-link" href="jodi.php">JODI</a></li>
<li class="nav-item"><a class="nav-link" href="single-patti.php">SINGLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="double-patti.php">DOUBLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="triple-patti.php">TRIPLE PATTI</a></li>
<li class="nav-item"><a class="nav-link" href="half-sangam.php">HALF SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="full-sangam.php">FULL SANGAM</a></li>
<li class="nav-item"><a class="nav-link" href="star-line.php">STARLINE</a></li>
<li class="nav-item"><a class="nav-link" href="howtoplay.php">HOW TO PLAY</a></li>
<li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
<li class="nav-item"><a class="nav-link" href="register.php">REGISTER</a></li>
 </ul></div></nav>
   </div>
<div class="myform">

	<div class="container-fluid fdklslf">
	    		<h2 class="text-center">JODI (10 KA 9000)</h2>
		<span id="lotterytimeerror" style="color:red;"></span>
		<h6>Select Your Game</h6>
		<form class="row" action="" method="POST" onsubmit="return confirm('Are You Sure ?\nOnce you Proceed You Cannot Revert.');">
			
<div class="form-group col-md-6 col-12">
			    
			  <label for="market">SELECT YOUR MARKET</label>
			  <select class="form-control" id="market" name="market" required>
			     <option value=""> Select Market </option>
          		                     
                                            <option value="RAJDHANI DAY" >RAJDHANI DAY (05:10 PM)</option>
                                        
                   
                                    
                                        
                   
                                    
                                        
                   
                                    
                                        
                   
                                    
                                        
                   
                                    
                                            <option value="SUPREME DAY" >SUPREME DAY (04:35 PM)</option>
                                        
                   
                                    
                                            <option value="KALYAN " >KALYAN  (06:30 PM)</option>
                                        
                   
                                    
                                            <option value="SRIDEVI NIGHT " >SRIDEVI NIGHT  (08:15 PM)</option>
                                        
                   
                                    
                                            <option value="SUPREME NIGHT " >SUPREME NIGHT  (10:35 PM)</option>
                                        
                   
                                    
                                            <option value="MILAN NIGHT " >MILAN NIGHT  (10:50 PM)</option>
                                        
                   
                                    
                                            <option value="RAJDHANI NIGHT " >RAJDHANI NIGHT  (11:10 PM)</option>
                                        
                   
                                    
                                            <option value="KALYAN NIGHT " >KALYAN NIGHT  (11:25 PM)</option>
                                        
                   
                                    
                                        
                   
                                    
                                            <option value="MAIN BAZAR " >MAIN BAZAR  (11:59 PM)</option>
                                        
                   
                              
 			  </select>
			</div>
			
			
			<div class="form-group col-md-6 col-12">
		    <label for="date">SELECT DATE</label>
		    <select class="form-control" id="date" name="date" required>
			<option value="26/10/2023">26/10/2023</option>
		    </select>
		  </div>

			<div style="display:none;" class="form-group col-12">
				<div class="form-group">
				  <!-- <label for="num6">Example multiple select</label> -->
					<ul class="list-ul form-control">
					    
					            				<li id="0" class="sel ddd0">0</li>
    					        				<li id="1" class="sel ddd1">1</li>
    					        				<li id="2" class="sel ddd2">2</li>
    					        				<li id="3" class="sel ddd3">3</li>
    					        				<li id="4" class="sel ddd4">4</li>
    					        				<li id="5" class="sel ddd5">5</li>
    					        				<li id="6" class="sel ddd6">6</li>
    					        				<li id="7" class="sel ddd7">7</li>
    					        				<li id="8" class="sel ddd8">8</li>
    					        				<li id="9" class="sel ddd9">9</li>
    					        				<li id="10" class="sel ddd10">10</li>
    					        				<li id="11" class="sel ddd11">11</li>
    					        				<li id="12" class="sel ddd12">12</li>
    					        				<li id="13" class="sel ddd13">13</li>
    					        				<li id="14" class="sel ddd14">14</li>
    					        				<li id="15" class="sel ddd15">15</li>
    					        				<li id="16" class="sel ddd16">16</li>
    					        				<li id="17" class="sel ddd17">17</li>
    					        				<li id="18" class="sel ddd18">18</li>
    					        				<li id="19" class="sel ddd19">19</li>
    					        				<li id="20" class="sel ddd20">20</li>
    					        				<li id="21" class="sel ddd21">21</li>
    					        				<li id="22" class="sel ddd22">22</li>
    					        				<li id="23" class="sel ddd23">23</li>
    					        				<li id="24" class="sel ddd24">24</li>
    					        				<li id="25" class="sel ddd25">25</li>
    					        				<li id="26" class="sel ddd26">26</li>
    					        				<li id="27" class="sel ddd27">27</li>
    					        				<li id="28" class="sel ddd28">28</li>
    					        				<li id="29" class="sel ddd29">29</li>
    					        				<li id="30" class="sel ddd30">30</li>
    					        				<li id="31" class="sel ddd31">31</li>
    					        				<li id="32" class="sel ddd32">32</li>
    					        				<li id="33" class="sel ddd33">33</li>
    					        				<li id="34" class="sel ddd34">34</li>
    					        				<li id="35" class="sel ddd35">35</li>
    					        				<li id="36" class="sel ddd36">36</li>
    					        				<li id="37" class="sel ddd37">37</li>
    					        				<li id="38" class="sel ddd38">38</li>
    					        				<li id="39" class="sel ddd39">39</li>
    					        				<li id="40" class="sel ddd40">40</li>
    					        				<li id="41" class="sel ddd41">41</li>
    					        				<li id="42" class="sel ddd42">42</li>
    					        				<li id="43" class="sel ddd43">43</li>
    					        				<li id="44" class="sel ddd44">44</li>
    					        				<li id="45" class="sel ddd45">45</li>
    					        				<li id="46" class="sel ddd46">46</li>
    					        				<li id="47" class="sel ddd47">47</li>
    					        				<li id="48" class="sel ddd48">48</li>
    					        				<li id="49" class="sel ddd49">49</li>
    					        				<li id="50" class="sel ddd50">50</li>
    					        				<li id="51" class="sel ddd51">51</li>
    					        				<li id="52" class="sel ddd52">52</li>
    					        				<li id="53" class="sel ddd53">53</li>
    					        				<li id="54" class="sel ddd54">54</li>
    					        				<li id="55" class="sel ddd55">55</li>
    					        				<li id="56" class="sel ddd56">56</li>
    					        				<li id="57" class="sel ddd57">57</li>
    					        				<li id="58" class="sel ddd58">58</li>
    					        				<li id="59" class="sel ddd59">59</li>
    					        				<li id="60" class="sel ddd60">60</li>
    					        				<li id="61" class="sel ddd61">61</li>
    					        				<li id="62" class="sel ddd62">62</li>
    					        				<li id="63" class="sel ddd63">63</li>
    					        				<li id="64" class="sel ddd64">64</li>
    					        				<li id="65" class="sel ddd65">65</li>
    					        				<li id="66" class="sel ddd66">66</li>
    					        				<li id="67" class="sel ddd67">67</li>
    					        				<li id="68" class="sel ddd68">68</li>
    					        				<li id="69" class="sel ddd69">69</li>
    					        				<li id="70" class="sel ddd70">70</li>
    					        				<li id="71" class="sel ddd71">71</li>
    					        				<li id="72" class="sel ddd72">72</li>
    					        				<li id="73" class="sel ddd73">73</li>
    					        				<li id="74" class="sel ddd74">74</li>
    					        				<li id="75" class="sel ddd75">75</li>
    					        				<li id="76" class="sel ddd76">76</li>
    					        				<li id="77" class="sel ddd77">77</li>
    					        				<li id="78" class="sel ddd78">78</li>
    					        				<li id="79" class="sel ddd79">79</li>
    					        				<li id="80" class="sel ddd80">80</li>
    					        				<li id="81" class="sel ddd81">81</li>
    					        				<li id="82" class="sel ddd82">82</li>
    					        				<li id="83" class="sel ddd83">83</li>
    					        				<li id="84" class="sel ddd84">84</li>
    					        				<li id="85" class="sel ddd85">85</li>
    					        				<li id="86" class="sel ddd86">86</li>
    					        				<li id="87" class="sel ddd87">87</li>
    					        				<li id="88" class="sel ddd88">88</li>
    					        				<li id="89" class="sel ddd89">89</li>
    					        				<li id="90" class="sel ddd90">90</li>
    					        				<li id="91" class="sel ddd91">91</li>
    					        				<li id="92" class="sel ddd92">92</li>
    					        				<li id="93" class="sel ddd93">93</li>
    					        				<li id="94" class="sel ddd94">94</li>
    					        				<li id="95" class="sel ddd95">95</li>
    					        				<li id="96" class="sel ddd96">96</li>
    					        				<li id="97" class="sel ddd97">97</li>
    					        				<li id="98" class="sel ddd98">98</li>
    					        				<li id="99" class="sel ddd99">99</li>
    											
					</ul>
				</div>
			</div>

		  <div class="form-group col-12">
				<div class="row ">
				    
				    
				        					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa0">
						<label>0</label>
						<input type="number" min="10"  class="nnnd" name="jodi_00" id="jodi_0" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa1">
						<label>1</label>
						<input type="number" min="10"  class="nnnd" name="jodi_01" id="jodi_1" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa2">
						<label>2</label>
						<input type="number" min="10"  class="nnnd" name="jodi_02" id="jodi_2" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa3">
						<label>3</label>
						<input type="number" min="10"  class="nnnd" name="jodi_03" id="jodi_3" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa4">
						<label>4</label>
						<input type="number" min="10"  class="nnnd" name="jodi_04" id="jodi_4" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa5">
						<label>5</label>
						<input type="number" min="10"  class="nnnd" name="jodi_05" id="jodi_5" value="" />
						
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa6">
						<label>6</label>
						<input type="number" min="10"  class="nnnd" name="jodi_06" id="jodi_6" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa7">
						<label>7</label>
						<input type="number" min="10"  class="nnnd" name="jodi_07" id="jodi_7" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa8">
						<label>8</label>
						<input type="number" min="10"  class="nnnd" name="jodi_08" id="jodi_8" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa9">
						<label>9</label>
						<input type="number" min="10"  class="nnnd" name="jodi_09" id="jodi_9" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa10">
						<label>10</label>
						<input type="number" min="10"  class="nnnd" name="jodi_10" id="jodi_10" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa11">
						<label>11</label>
						<input type="number" min="10"  class="nnnd" name="jodi_11" id="jodi_11" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa12">
						<label>12</label>
						<input type="number" min="10"  class="nnnd" name="jodi_12" id="jodi_12" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa13">
						<label>13</label>
						<input type="number" min="10"  class="nnnd" name="jodi_13" id="jodi_13" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa14">
						<label>14</label>
						<input type="number" min="10"  class="nnnd" name="jodi_14" id="jodi_14" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa15">
						<label>15</label>
						<input type="number" min="10"  class="nnnd" name="jodi_15" id="jodi_15" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa16">
						<label>16</label>
						<input type="number" min="10"  class="nnnd" name="jodi_16" id="jodi_16" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa17">
						<label>17</label>
						<input type="number" min="10"  class="nnnd" name="jodi_17" id="jodi_17" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa18">
						<label>18</label>
						<input type="number" min="10"  class="nnnd" name="jodi_18" id="jodi_18" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa19">
						<label>19</label>
						<input type="number" min="10"  class="nnnd" name="jodi_19" id="jodi_19" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa20">
						<label>20</label>
						<input type="number" min="10"  class="nnnd" name="jodi_20" id="jodi_20" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa21">
						<label>21</label>
						<input type="number" min="10"  class="nnnd" name="jodi_21" id="jodi_21" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa22">
						<label>22</label>
						<input type="number" min="10"  class="nnnd" name="jodi_22" id="jodi_22" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa23">
						<label>23</label>
						<input type="number" min="10"  class="nnnd" name="jodi_23" id="jodi_23" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa24">
						<label>24</label>
						<input type="number" min="10"  class="nnnd" name="jodi_24" id="jodi_24" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa25">
						<label>25</label>
						<input type="number" min="10"  class="nnnd" name="jodi_25" id="jodi_25" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa26">
						<label>26</label>
						<input type="number" min="10"  class="nnnd" name="jodi_26" id="jodi_26" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa27">
						<label>27</label>
						<input type="number" min="10"  class="nnnd" name="jodi_27" id="jodi_27" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa28">
						<label>28</label>
						<input type="number" min="10"  class="nnnd" name="jodi_28" id="jodi_28" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa29">
						<label>29</label>
						<input type="number" min="10"  class="nnnd" name="jodi_29" id="jodi_29" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa30">
						<label>30</label>
						<input type="number" min="10"  class="nnnd" name="jodi_30" id="jodi_30" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa31">
						<label>31</label>
						<input type="number" min="10"  class="nnnd" name="jodi_31" id="jodi_31" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa32">
						<label>32</label>
						<input type="number" min="10"  class="nnnd" name="jodi_32" id="jodi_32" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa33">
						<label>33</label>
						<input type="number" min="10"  class="nnnd" name="jodi_33" id="jodi_33" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa34">
						<label>34</label>
						<input type="number" min="10"  class="nnnd" name="jodi_34" id="jodi_34" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa35">
						<label>35</label>
						<input type="number" min="10"  class="nnnd" name="jodi_35" id="jodi_35" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa36">
						<label>36</label>
						<input type="number" min="10"  class="nnnd" name="jodi_36" id="jodi_36" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa37">
						<label>37</label>
						<input type="number" min="10"  class="nnnd" name="jodi_37" id="jodi_37" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa38">
						<label>38</label>
						<input type="number" min="10"  class="nnnd" name="jodi_38" id="jodi_38" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa39">
						<label>39</label>
						<input type="number" min="10"  class="nnnd" name="jodi_39" id="jodi_39" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa40">
						<label>40</label>
						<input type="number" min="10"  class="nnnd" name="jodi_40" id="jodi_40" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa41">
						<label>41</label>
						<input type="number" min="10"  class="nnnd" name="jodi_41" id="jodi_41" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa42">
						<label>42</label>
						<input type="number" min="10"  class="nnnd" name="jodi_42" id="jodi_42" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa43">
						<label>43</label>
						<input type="number" min="10"  class="nnnd" name="jodi_43" id="jodi_43" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa44">
						<label>44</label>
						<input type="number" min="10"  class="nnnd" name="jodi_44" id="jodi_44" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa45">
						<label>45</label>
						<input type="number" min="10"  class="nnnd" name="jodi_45" id="jodi_45" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa46">
						<label>46</label>
						<input type="number" min="10"  class="nnnd" name="jodi_46" id="jodi_46" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa47">
						<label>47</label>
						<input type="number" min="10"  class="nnnd" name="jodi_47" id="jodi_47" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa48">
						<label>48</label>
						<input type="number" min="10"  class="nnnd" name="jodi_48" id="jodi_48" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa49">
						<label>49</label>
						<input type="number" min="10"  class="nnnd" name="jodi_49" id="jodi_49" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa50">
						<label>50</label>
						<input type="number" min="10"  class="nnnd" name="jodi_50" id="jodi_50" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa51">
						<label>51</label>
						<input type="number" min="10"  class="nnnd" name="jodi_51" id="jodi_51" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa52">
						<label>52</label>
						<input type="number" min="10"  class="nnnd" name="jodi_52" id="jodi_52" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa53">
						<label>53</label>
						<input type="number" min="10"  class="nnnd" name="jodi_53" id="jodi_53" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa54">
						<label>54</label>
						<input type="number" min="10"  class="nnnd" name="jodi_54" id="jodi_54" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa55">
						<label>55</label>
						<input type="number" min="10"  class="nnnd" name="jodi_55" id="jodi_55" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa56">
						<label>56</label>
						<input type="number" min="10"  class="nnnd" name="jodi_56" id="jodi_56" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa57">
						<label>57</label>
						<input type="number" min="10"  class="nnnd" name="jodi_57" id="jodi_57" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa58">
						<label>58</label>
						<input type="number" min="10"  class="nnnd" name="jodi_58" id="jodi_58" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa59">
						<label>59</label>
						<input type="number" min="10"  class="nnnd" name="jodi_59" id="jodi_59" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa60">
						<label>60</label>
						<input type="number" min="10"  class="nnnd" name="jodi_60" id="jodi_60" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa61">
						<label>61</label>
						<input type="number" min="10"  class="nnnd" name="jodi_61" id="jodi_61" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa62">
						<label>62</label>
						<input type="number" min="10"  class="nnnd" name="jodi_62" id="jodi_62" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa63">
						<label>63</label>
						<input type="number" min="10"  class="nnnd" name="jodi_63" id="jodi_63" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa64">
						<label>64</label>
						<input type="number" min="10"  class="nnnd" name="jodi_64" id="jodi_64" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa65">
						<label>65</label>
						<input type="number" min="10"  class="nnnd" name="jodi_65" id="jodi_65" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa66">
						<label>66</label>
						<input type="number" min="10"  class="nnnd" name="jodi_66" id="jodi_66" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa67">
						<label>67</label>
						<input type="number" min="10"  class="nnnd" name="jodi_67" id="jodi_67" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa68">
						<label>68</label>
						<input type="number" min="10"  class="nnnd" name="jodi_68" id="jodi_68" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa69">
						<label>69</label>
						<input type="number" min="10"  class="nnnd" name="jodi_69" id="jodi_69" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa70">
						<label>70</label>
						<input type="number" min="10"  class="nnnd" name="jodi_70" id="jodi_70" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa71">
						<label>71</label>
						<input type="number" min="10"  class="nnnd" name="jodi_71" id="jodi_71" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa72">
						<label>72</label>
						<input type="number" min="10"  class="nnnd" name="jodi_72" id="jodi_72" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa73">
						<label>73</label>
						<input type="number" min="10"  class="nnnd" name="jodi_73" id="jodi_73" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa74">
						<label>74</label>
						<input type="number" min="10"  class="nnnd" name="jodi_74" id="jodi_74" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa75">
						<label>75</label>
						<input type="number" min="10"  class="nnnd" name="jodi_75" id="jodi_75" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa76">
						<label>76</label>
						<input type="number" min="10"  class="nnnd" name="jodi_76" id="jodi_76" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa77">
						<label>77</label>
						<input type="number" min="10"  class="nnnd" name="jodi_77" id="jodi_77" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa78">
						<label>78</label>
						<input type="number" min="10"  class="nnnd" name="jodi_78" id="jodi_78" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa79">
						<label>79</label>
						<input type="number" min="10"  class="nnnd" name="jodi_79" id="jodi_79" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa80">
						<label>80</label>
						<input type="number" min="10"  class="nnnd" name="jodi_80" id="jodi_80" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa81">
						<label>81</label>
						<input type="number" min="10"  class="nnnd" name="jodi_81" id="jodi_81" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa82">
						<label>82</label>
						<input type="number" min="10"  class="nnnd" name="jodi_82" id="jodi_82" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa83">
						<label>83</label>
						<input type="number" min="10"  class="nnnd" name="jodi_83" id="jodi_83" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa84">
						<label>84</label>
						<input type="number" min="10"  class="nnnd" name="jodi_84" id="jodi_84" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa85">
						<label>85</label>
						<input type="number" min="10"  class="nnnd" name="jodi_85" id="jodi_85" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa86">
						<label>86</label>
						<input type="number" min="10"  class="nnnd" name="jodi_86" id="jodi_86" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa87">
						<label>87</label>
						<input type="number" min="10"  class="nnnd" name="jodi_87" id="jodi_87" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa88">
						<label>88</label>
						<input type="number" min="10"  class="nnnd" name="jodi_88" id="jodi_88" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa89">
						<label>89</label>
						<input type="number" min="10"  class="nnnd" name="jodi_89" id="jodi_89" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa90">
						<label>90</label>
						<input type="number" min="10"  class="nnnd" name="jodi_90" id="jodi_90" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa91">
						<label>91</label>
						<input type="number" min="10"  class="nnnd" name="jodi_91" id="jodi_91" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa92">
						<label>92</label>
						<input type="number" min="10"  class="nnnd" name="jodi_92" id="jodi_92" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa93">
						<label>93</label>
						<input type="number" min="10"  class="nnnd" name="jodi_93" id="jodi_93" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa94">
						<label>94</label>
						<input type="number" min="10"  class="nnnd" name="jodi_94" id="jodi_94" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa95">
						<label>95</label>
						<input type="number" min="10"  class="nnnd" name="jodi_95" id="jodi_95" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa96">
						<label>96</label>
						<input type="number" min="10"  class="nnnd" name="jodi_96" id="jodi_96" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa97">
						<label>97</label>
						<input type="number" min="10"  class="nnnd" name="jodi_97" id="jodi_97" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa98">
						<label>98</label>
						<input type="number" min="10"  class="nnnd" name="jodi_98" id="jodi_98" value="" />
					    </div>
    					    					
    					<div class="dynamic-input col-lg-3 col-md-4 my-sk col-6 aa99">
						<label>99</label>
						<input type="number" min="10"  class="nnnd" name="jodi_99" id="jodi_99" value="" />
					    </div>
    										
				</div>
		  </div>
		  
		  <div class="form-group col-12">
		  	<h5 class="shww">
		  		<span class="aa">Total Point :</span>
		  		<span class="bb">00</span>
		  		<input type="hidden" name="total_point" id="total_point" value="">
		  	</h5>
		  </div>
		  <div class="form-group col-12 justify-content-center d-flex">
		      							You Need to Login First.
							        </div>
		</form>
	</div>


<h3>DOWNLOAD THE GAME APP</h3> 
	<h3>AND START EARNING</h3>
	<div class="text-center mt-2 mb-2">
	    
	    <a href="https://matka.games/apk/online_matka_play.apk" class="btn btn-success" style="font-size: 25px;text-transform: uppercase;    background-image: linear-gradient(45deg, #E91E63, #F44336);    border-color: #fff;   border-radius: 10px;"> 
						<i class="fas fa-download"></i>
						<span>&nbsp;</span>
						<span>Download APP</span>
					</a>
	</div>

<div class="my-btn">
<a href="#top" class="gototop"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAAxUlEQVQoz33SsQ3EIAwFUEdXUDICozAakVjssgkjUFIgfP425xQ5XYroJcFfxIaIiJn0CsxNkZmngtm+HcBpS2xRBLogAUNQgLWLtOyLw3DSy/C2GAQ5oqFbHhId2TB/oBgWMPPGSADCEAq0sHHVjXpthGZYsRfFTCMrRp5J0cuKClkaFFJcFVVN+r4BWClBxKiVIMIND1SG5K8kOxzYclr35v/84LMb3qhnD7293vDnLO4x+eB8lD5cH7cfgPtI+CGxY/MB2UCCRHC5zcsAAAAASUVORK5CYII=" width="25" height="25" style="width: 25px;"> </a>
<a href="https://api.whatsapp.com/send?phone=919339447115&amp;text=I%20have%20Some%20query%20Regarding%20onlinematkaplay.net" class="whatapp"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABAAQMAAACQp+OdAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURQAAAP///6XZn90AAAABdFJOUwBA5thmAAAA9klEQVQoz22SzW3EIBCFB3HgSAk0EonSzC1tTQfbgjsIRx8QL/MGWEXRWpb5zPwyD5FPD7DWBNwOBRgOF5Yt2IpmEIHLnRI0oNN3itRH1iczrJo9TUYrI1mAoQZhetImwdNXlehQVBJTSL4l9dIc8m12+90QDZQZ42P+1/0HgkG7rBlL+4bqIAZCnwW6obYDZ6fc/yGfcG/NYUQltAjrhrUCvoeD4AdenSNjPyrVISunaa3yaJgLIqady17B2FA697tP44A1l/qeWHJlsIFTzYQ4CX1NPr/GloGqUR0r3TP1KhQQekA2uFzD3LuXC+4iX2Z9Pt6UX/MAtvTv+yAIAAAAAElFTkSuQmCC" width="25" height="25" style="width:25px;"></a>





<!--<div class="down-div"> 
<a href="https://matka.games/apk/online_matka_play.apk" class="download-app"> 
<span>
<i class="fas fa-download"></i>&nbsp;&nbsp;Download Android App
</span>
</a>
</div>-->


</div>



<script> 
if ('serviceWorker' in navigator) {
    console.log("Will the service worker register?");
    navigator.serviceWorker.register('service-worker.js')
        .then(function(reg) {
            console.log("Yes, it did.");
        }).catch(function(err) {
            console.log("No it didn't. This happened:", err)
        });
}
 
</script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="cssjs/p.js"></script>
<script src="cssjs/bt.js"></script>
<script src="cssjs/app.js"></script>
<script type="text/javascript">
function get_dates(market_id){var date=document.getElementById('date').value; if(market_id=="" || market_id==null){document.getElementById('lotterytimeerror').innerHTML="Please select market!!";return}$.ajax({url: 'getdatebylotteryId.php?market_id=' + market_id +'&date=' + date,success: function(response){var splited=response.split("|");var flag=splited[0];var dates=splited[1];if(flag !=1){document.getElementById('lotterytimeerror').innerHTML="Today lottery play time is closed , you can play another day lottery."; alert('Today lottery play time is closed , you can play another day lottery');document.getElementById('date').innerHTML=dates}else{document.getElementById('lotterytimeerror').innerHTML=""; document.getElementById('date').innerHTML=dates}}})}
</script>
<script>

$('li').click(function(e){ 
    var valuel = $(this).html()
    var myClassaa = 'aa'+valuel;
    $(this).toggleClass("selected");
    console.log(valuel);
    console.log(myClassaa);
  
   if ($(this).hasClass("selected")) {  
    $("."+myClassaa).addClass('show-div');
   }  else {
    $("."+myClassaa).removeClass('show-div');
   }

});

                            					
					    
					    $('.delete.dd0').click(function(){
                            $('.ddd0').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_0").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd1').click(function(){
                            $('.ddd1').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_1").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd2').click(function(){
                            $('.ddd2').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_2").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd3').click(function(){
                            $('.ddd3').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_3").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd4').click(function(){
                            $('.ddd4').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_4").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd5').click(function(){
                            $('.ddd5').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_5").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd6').click(function(){
                            $('.ddd6').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_6").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd7').click(function(){
                            $('.ddd7').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_7").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd8').click(function(){
                            $('.ddd8').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_8").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd9').click(function(){
                            $('.ddd9').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_9").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd10').click(function(){
                            $('.ddd10').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_10").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd11').click(function(){
                            $('.ddd11').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_11").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd12').click(function(){
                            $('.ddd12').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_12").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd13').click(function(){
                            $('.ddd13').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_13").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd14').click(function(){
                            $('.ddd14').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_14").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd15').click(function(){
                            $('.ddd15').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_15").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd16').click(function(){
                            $('.ddd16').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_16").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd17').click(function(){
                            $('.ddd17').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_17").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd18').click(function(){
                            $('.ddd18').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_18").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd19').click(function(){
                            $('.ddd19').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_19").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd20').click(function(){
                            $('.ddd20').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_20").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd21').click(function(){
                            $('.ddd21').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_21").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd22').click(function(){
                            $('.ddd22').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_22").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd23').click(function(){
                            $('.ddd23').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_23").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd24').click(function(){
                            $('.ddd24').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_24").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd25').click(function(){
                            $('.ddd25').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_25").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd26').click(function(){
                            $('.ddd26').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_26").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd27').click(function(){
                            $('.ddd27').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_27").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd28').click(function(){
                            $('.ddd28').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_28").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd29').click(function(){
                            $('.ddd29').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_29").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd30').click(function(){
                            $('.ddd30').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_30").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd31').click(function(){
                            $('.ddd31').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_31").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd32').click(function(){
                            $('.ddd32').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_32").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd33').click(function(){
                            $('.ddd33').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_33").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd34').click(function(){
                            $('.ddd34').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_34").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd35').click(function(){
                            $('.ddd35').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_35").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd36').click(function(){
                            $('.ddd36').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_36").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd37').click(function(){
                            $('.ddd37').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_37").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd38').click(function(){
                            $('.ddd38').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_38").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd39').click(function(){
                            $('.ddd39').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_39").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd40').click(function(){
                            $('.ddd40').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_40").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd41').click(function(){
                            $('.ddd41').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_41").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd42').click(function(){
                            $('.ddd42').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_42").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd43').click(function(){
                            $('.ddd43').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_43").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd44').click(function(){
                            $('.ddd44').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_44").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd45').click(function(){
                            $('.ddd45').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_45").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd46').click(function(){
                            $('.ddd46').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_46").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd47').click(function(){
                            $('.ddd47').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_47").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd48').click(function(){
                            $('.ddd48').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_48").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd49').click(function(){
                            $('.ddd49').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_49").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd50').click(function(){
                            $('.ddd50').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_50").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd51').click(function(){
                            $('.ddd51').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_51").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd52').click(function(){
                            $('.ddd52').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_52").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd53').click(function(){
                            $('.ddd53').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_53").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd54').click(function(){
                            $('.ddd54').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_54").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd55').click(function(){
                            $('.ddd55').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_55").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd56').click(function(){
                            $('.ddd56').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_56").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd57').click(function(){
                            $('.ddd57').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_57").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd58').click(function(){
                            $('.ddd58').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_58").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd59').click(function(){
                            $('.ddd59').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_59").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd60').click(function(){
                            $('.ddd60').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_60").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd61').click(function(){
                            $('.ddd61').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_61").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd62').click(function(){
                            $('.ddd62').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_62").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd63').click(function(){
                            $('.ddd63').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_63").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd64').click(function(){
                            $('.ddd64').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_64").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd65').click(function(){
                            $('.ddd65').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_65").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd66').click(function(){
                            $('.ddd66').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_66").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd67').click(function(){
                            $('.ddd67').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_67").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd68').click(function(){
                            $('.ddd68').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_68").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd69').click(function(){
                            $('.ddd69').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_69").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd70').click(function(){
                            $('.ddd70').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_70").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd71').click(function(){
                            $('.ddd71').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_71").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd72').click(function(){
                            $('.ddd72').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_72").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd73').click(function(){
                            $('.ddd73').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_73").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd74').click(function(){
                            $('.ddd74').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_74").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd75').click(function(){
                            $('.ddd75').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_75").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd76').click(function(){
                            $('.ddd76').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_76").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd77').click(function(){
                            $('.ddd77').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_77").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd78').click(function(){
                            $('.ddd78').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_78").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd79').click(function(){
                            $('.ddd79').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_79").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd80').click(function(){
                            $('.ddd80').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_80").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd81').click(function(){
                            $('.ddd81').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_81").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd82').click(function(){
                            $('.ddd82').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_82").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd83').click(function(){
                            $('.ddd83').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_83").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd84').click(function(){
                            $('.ddd84').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_84").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd85').click(function(){
                            $('.ddd85').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_85").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd86').click(function(){
                            $('.ddd86').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_86").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd87').click(function(){
                            $('.ddd87').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_87").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd88').click(function(){
                            $('.ddd88').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_88").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd89').click(function(){
                            $('.ddd89').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_89").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd90').click(function(){
                            $('.ddd90').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_90").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd91').click(function(){
                            $('.ddd91').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_91").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd92').click(function(){
                            $('.ddd92').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_92").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd93').click(function(){
                            $('.ddd93').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_93").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd94').click(function(){
                            $('.ddd94').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_94").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd95').click(function(){
                            $('.ddd95').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_95").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd96').click(function(){
                            $('.ddd96').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_96").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd97').click(function(){
                            $('.ddd97').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_97").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd98').click(function(){
                            $('.ddd98').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_98").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					    					
					    
					    $('.delete.dd99').click(function(){
                            $('.ddd99').removeClass('selected');
                            $(this).closest("div").removeClass('show-div');
                            document.getElementById("jodi_99").value = '';
                            
                            var total = 0;
                              $('.nnnd').each(function() {
                                total += parseInt(this.value, 10) || 0;
                              });
                              $('.bb').html(total);
                              document.getElementById("total_point").value = total;
                        })

    					
// sum 
$('.myform').on('input', '.nnnd', function() {
  var total = 0;
  $('.nnnd').each(function() {
    total += parseInt(this.value, 10) || 0;
  });
  $('.bb').html(total);
  document.getElementById("total_point").value = total;
})


$('.nnnd').bind('copy paste cut',function(e) {
  e.preventDefault();
});
</script>

</body>
</html>